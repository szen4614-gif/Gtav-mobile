# N11 4.0 — Real Component Integration

N11 4.0 is structured as a real launcher/runtime pipeline rather than a list of placeholder subsystem names.

## Runtime acquisition

The Android app downloads and verifies ARM64 OpenJDK runtime archives before extraction. Current pinned artifacts are JRE 17, 21 and 25 from the public AngelAuraMC OpenJDK build release center. Their SHA-256 values are recorded in `N11_ANDROID/app/src/main/assets/n11/components.json` and `N11_MINECRAFT/n11minecraft/runtime_manifest.py`.

JRE 8 is intentionally not enabled as an unverified binary. It must be added with a pinned SHA-256 from a trusted release before it is offered by the installer.

## Minecraft acquisition

`MojangVersionService` uses Mojang's version manifest and per-version metadata. The launch engine resolves libraries, assets, natives, modern `arguments` rules and legacy `minecraftArguments`.

## Authentication

The N11 authentication pipeline implements Microsoft device-code acquisition followed by Xbox Live, XSTS and Minecraft Services profile exchange. Tokens are intended to be stored using Android Keystore-backed encryption.

## Graphics/runtime architecture

The N11 Android module contains explicit renderer descriptors for OpenGL ES, GL4ES, Vulkan, ANGLE and software fallback. Native dependencies remain separately licensed components; N11 does not copy the Zalith APK's binaries.

## Legal boundary

Zalith Launcher 2 is GPL-3.0 and publicly documents its dependencies. PojavLauncher/Amethyst documents OpenJDK, LWJGL, GL4ES, OpenAL and renderer components. N11 references these projects and their public interfaces/documentation but does not claim their code or binaries as N11 code.
