# Zalith 2.4.9 — reference audit for N11 4.0

This document records architecture observations from the user-supplied APK. It is **not** copied source code and does not redistribute its binaries.

Observed families include ARM native libraries for LWJGL/GLFW/OpenGL, GL4ES, OpenAL, shader compilation/SPIR-V, ANGLE/OSMesa, VirGL, AWT compatibility, process execution, and FSR; assets include Caciocavallo compatibility jars, launcher agents/patchers, LWJGL GLFW classes, auth components, and JRE 8/17/21/25 runtime archives.

The public Zalith Launcher 2 project states that it uses PojavLauncher as its core launch engine and Jetpack Compose/Material 3 for its Android UI. The project is GPL-3.0 and contains additional attribution/license requirements. N11 4.0 therefore uses the APK as a compatibility/architecture reference only and keeps N11-owned code separate.

Primary N11 4.0 additions:
- metadata/version resolution and classpath assembly
- runtime discovery/selection and process supervision
- instance/mod-loader boundaries
- Android device probing and Java process bridge
- native page-size/ABI bridge
- renderer capability selection
- explicit external-component boundaries and license tracking
