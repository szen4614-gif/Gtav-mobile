# N11 4.0

N11 4.0 is a substantial architecture expansion over 3.0, guided by the user-supplied Zalith 2.4.9 APK and public Zalith Launcher 2 architecture documentation.

## Added
- N11 Minecraft launch engine with metadata parsing and classpath assembly.
- Java runtime discovery and selection.
- Process supervisor with stdout capture and lifecycle control.
- Minecraft instance manager.
- Mod-loader profile boundary for Vanilla/Fabric/Forge/NeoForge/Quilt.
- Renderer capability selection for Vulkan/OpenGL ES/GL4ES/ANGLE/software fallback.
- Android device probing.
- Android Java process execution bridge.
- Native JNI ABI and actual page-size detection.
- Explicit external-component/license matrix.
- Reference audit of the supplied Zalith 2.4.9 APK.

## Important
4.0 is **source-ready architecture**, not a falsely labeled finished APK. It does not bundle third-party JRE/LWJGL/GL4ES/OpenAL/Caciocavallo binaries from Zalith. Those components must be acquired from their legitimate upstream sources, verified, and integrated for a production build.

Android 15+ 16 KB support requires all native dependencies to be rebuilt/aligned appropriately; Android documentation recommends AGP 8.5.1+ and NDK r28+ for this path.
