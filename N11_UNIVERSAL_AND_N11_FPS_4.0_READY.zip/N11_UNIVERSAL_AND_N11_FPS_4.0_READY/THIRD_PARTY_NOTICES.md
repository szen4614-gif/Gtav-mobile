# Third-party notices

No third-party binary distributions are bundled by this release except the
user-supplied reference APK kept under `artifacts/reference/`. Before shipping
production binaries, populate this document with the exact licenses and source
URLs for every AndroidX, Kotlin, LWJGL, loader, renderer, Java runtime and
other external component actually packaged into the APK.

