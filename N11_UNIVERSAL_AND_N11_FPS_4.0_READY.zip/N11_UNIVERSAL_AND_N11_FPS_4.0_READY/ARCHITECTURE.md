# N11 Ecosystem 3.0 architecture

```text
                    N11 Universal
                         |
             +-----------+-----------+
             |                       |
          N11 FPS               N11 Android
             |                       |
      performance model        Java/Kotlin/JNI
             |                       |
             +-----------+-----------+
                         |
                  N11 Minecraft
                     backend
                         |
          versions / assets / JVM / mods
                         |
             external game/services/artifacts
```

N11 Universal is the center of runtime orchestration. N11 FPS produces
measurements and conservative decisions. N11 Android provides Android lifecycle,
filesystem, process and native boundaries. N11 Minecraft handles the launcher
state machine and legal acquisition of external artifacts.
