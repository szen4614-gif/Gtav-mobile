# N11 3.0 status report

The original 2.0 ZIP was a Python prototype with 41 files and no Android
project, JNI source, Minecraft launcher backend, or native build. Version 3.0
keeps the working prototype but adds 100+ source/configuration files covering
the missing architectural layers.

The requested capability list is tracked in `requested_feature_matrix.json`.
A feature is marked `IMPLEMENTED` only when executable source exists for that
feature in this tree; `SCAFFOLD` means the API/configuration boundary is ready
but platform-specific/third-party work remains; `EXTERNAL`/`NOT_BUNDLED` means
the artifact or service belongs outside this repository.

