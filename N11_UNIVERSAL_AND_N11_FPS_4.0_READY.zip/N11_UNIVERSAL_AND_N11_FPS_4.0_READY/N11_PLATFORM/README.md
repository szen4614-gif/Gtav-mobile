# N11 Platform Layer

This directory documents the cross-platform contracts shared by N11 Universal,
N11 FPS and the Android application. The rule is that N11 stays at the center:
platform-specific code reports capabilities and state into N11 contracts, and
N11 decides what can be scheduled/adapted.
