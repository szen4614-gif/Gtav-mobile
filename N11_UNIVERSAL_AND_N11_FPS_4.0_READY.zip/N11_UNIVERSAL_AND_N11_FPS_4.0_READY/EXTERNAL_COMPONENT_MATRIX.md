# N11 4.0 external component matrix

N11 does not pretend third-party engines are implemented merely because an integration class exists.

| Component | N11 status | Source/ownership boundary |
|---|---|---|
| JVM/JRE 8/17/21/25 | provider boundary | runtime artifacts must be sourced/licensed and verified |
| LWJGL | adapter boundary | use compatible upstream build |
| GLFW | Android adapter boundary | requires native implementation |
| GL4ES | adapter boundary | upstream/open-source component, license required |
| OpenAL Soft | adapter boundary | upstream component, license required |
| Caciocavallo | compatibility boundary | upstream component, license required |
| ANGLE/OSMesa/VirGL | optional renderer backends | external binaries, verify ABI/license |
| Shaderc/SPIR-V | shader backend | external/upstream component |
| Fabric/Forge/NeoForge/Quilt | loader adapters | versioned external projects |
| Microsoft/Xbox/Minecraft auth | service integration | credentials/tokens handled securely |
| Minecraft assets/libraries | downloader | fetched per official metadata and license terms |

A production release must pass license, checksum, ABI, 16 KB alignment, and runtime smoke tests for every selected external artifact.
