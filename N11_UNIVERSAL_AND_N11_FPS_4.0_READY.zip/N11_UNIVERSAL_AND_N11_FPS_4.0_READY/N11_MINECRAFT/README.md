# N11 Minecraft Backend

This module provides launcher-side orchestration contracts. It does not ship
Minecraft binaries, Microsoft tokens, third-party mod jars or a proprietary
Java runtime. Those are acquired through user-authorized sources and checked
before use.

The N11 runtime owns the orchestration sequence:

`device -> runtime -> version metadata -> assets/libraries -> mods/shaders ->
launch arguments -> process supervision -> telemetry -> recovery`.
