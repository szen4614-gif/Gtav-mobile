from __future__ import annotations
from pathlib import Path
from .metadata_resolver import LibraryArtifact

class ClasspathBuilder:
    def build(self, libraries: list[LibraryArtifact], root: Path, client_jar: Path, natives: list[Path]=()) -> list[Path]:
        result=[]
        for lib in libraries:
            p=root/lib.path
            if p.exists(): result.append(p)
        result.extend(natives)
        if client_jar.exists(): result.append(client_jar)
        return result
