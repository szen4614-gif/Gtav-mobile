from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib
import urllib.request

@dataclass(frozen=True)
class DownloadSpec:
    url: str
    destination: Path
    expected_sha1: str | None = None

class DownloadManager:
    def download(self, spec: DownloadSpec, chunk_size: int = 1024 * 1024) -> Path:
        spec.destination.parent.mkdir(parents=True, exist_ok=True)
        part = spec.destination.with_suffix(spec.destination.suffix + ".part")
        offset = part.stat().st_size if part.exists() else 0
        headers = {"User-Agent": "N11-Minecraft/3.0"}
        if offset:
            headers["Range"] = f"bytes={offset}-"
        request = urllib.request.Request(spec.url, headers=headers)
        try:
            response = urllib.request.urlopen(request, timeout=60)
        except Exception:
            if offset:
                offset = 0
                part.unlink(missing_ok=True)
                request = urllib.request.Request(spec.url, headers={"User-Agent": "N11-Minecraft/3.0"})
                response = urllib.request.urlopen(request, timeout=60)
            else:
                raise
        mode = "ab" if offset and getattr(response, "status", 200) == 206 else "wb"
        with response, part.open(mode) as out:
            while chunk := response.read(chunk_size):
                out.write(chunk)
        part.replace(spec.destination)
        if spec.expected_sha1:
            digest = hashlib.sha1(spec.destination.read_bytes()).hexdigest()
            if digest.lower() != spec.expected_sha1.lower():
                spec.destination.unlink(missing_ok=True)
                raise ValueError("download SHA-1 mismatch")
        return spec.destination
