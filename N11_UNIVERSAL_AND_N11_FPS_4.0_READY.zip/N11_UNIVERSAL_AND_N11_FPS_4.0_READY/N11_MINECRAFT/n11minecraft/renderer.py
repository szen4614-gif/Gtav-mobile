from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class RendererCapabilities:
    opengles:bool=False; vulkan:bool=False; gl4es:bool=False; angle:bool=False; shaderc:bool=False

class RendererBackendSelector:
    def choose(self,c:RendererCapabilities)->str:
        if c.vulkan: return "vulkan"
        if c.opengles and c.gl4es: return "gl4es"
        if c.opengles and c.angle: return "angle"
        if c.opengles: return "opengles"
        return "software"
