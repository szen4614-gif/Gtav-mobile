from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class LibraryArtifact:
    name: str
    path: Path
    url: str
    sha1: str | None = None
    size: int | None = None

class LibraryResolver:
    def resolve(self, libraries: list[dict], os_name: str = "linux", arch: str = "arm64"):
        out = []
        for lib in libraries:
            dl = lib.get("downloads", {}).get("artifact")
            if not dl: continue
            path = Path(lib.get("name", "library").replace(":", "/"))
            out.append(LibraryArtifact(lib["name"], path, dl["url"], dl.get("sha1"), dl.get("size")))
        return out
