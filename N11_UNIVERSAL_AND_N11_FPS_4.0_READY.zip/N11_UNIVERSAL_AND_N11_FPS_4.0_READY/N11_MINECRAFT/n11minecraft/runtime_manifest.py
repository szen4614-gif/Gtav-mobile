from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class RuntimeArtifact:
    major:int; abi:str; url:str; sha256:str; archive:str

# Current verified public Amethyst OpenJDK ARM64 artifacts. N11 downloads them at runtime;
# they are not silently copied from the Zalith APK.
RUNTIMES = (
 RuntimeArtifact(8,"arm64-v8a","https://github.com/AngelAuraMC/angelauramc-openjdk-build/releases/download/download/jre8-android-arm64.tar.xz","","jre8-android-arm64.tar.xz"),
 RuntimeArtifact(17,"arm64-v8a","https://github.com/AngelAuraMC/angelauramc-openjdk-build/releases/download/download/jre17-android-arm64.tar.xz","e162c860fe05ee4a4e4af7606437419879f6c748386a7b09fa77d10db6a64091","jre17-android-arm64.tar.xz"),
 RuntimeArtifact(21,"arm64-v8a","https://github.com/AngelAuraMC/angelauramc-openjdk-build/releases/download/download/jre21-android-arm64.tar.xz","8d41ec401ee59f7722df60ed991f81ad146e130452804bfdd8a05d3436f7bbfe","jre21-android-arm64.tar.xz"),
 RuntimeArtifact(25,"arm64-v8a","https://github.com/AngelAuraMC/angelauramc-openjdk-build/releases/download/download/jre25-android-arm64.tar.xz","d3eb7afe2240c26728a1bb440502c5f18ac3883e932d202dd7f0c9bcbbce4c37","jre25-android-arm64.tar.xz"),
)
