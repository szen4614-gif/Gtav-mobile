from __future__ import annotations
from dataclasses import dataclass
import time

@dataclass
class ProcessWatchdog:
    timeout_s: float = 10.0

    def classify_exit(self, returncode: int | None) -> str:
        if returncode is None: return "running"
        return "clean" if returncode == 0 else "crashed"

    def recovery_delay(self, attempt: int) -> float:
        return min(30.0, max(0.25, 0.5 * (2 ** max(0, attempt - 1))))
