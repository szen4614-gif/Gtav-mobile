from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json

@dataclass(frozen=True)
class VersionInfo:
    id: str
    url: str
    type: str = "release"
    java_major: int = 17

class VersionManifest:
    def __init__(self, versions=()): self.versions={v.id:v for v in versions}
    @classmethod
    def from_json(cls, path: Path):
        data=json.loads(path.read_text(encoding="utf-8"))
        out=[]
        for v in data.get("versions",[]):
            out.append(VersionInfo(v["id"],v.get("url", ""),v.get("type","release"),8))
        return cls(out)
    def get(self, version: str)->VersionInfo:
        if version not in self.versions: raise KeyError(f"Minecraft version not indexed: {version}")
        return self.versions[version]
