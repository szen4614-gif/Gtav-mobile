from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib, os, tempfile, urllib.request

@dataclass(frozen=True)
class DownloadSpec:
    url: str
    destination: Path
    sha1: str | None = None
    sha256: str | None = None
    size: int | None = None

class DownloadManager:
    """Resumable, atomic, hash-verified downloader used by N11 runtime/MC acquisition."""
    def download(self, spec: DownloadSpec) -> Path:
        spec.destination.parent.mkdir(parents=True, exist_ok=True)
        tmp = spec.destination.with_name(spec.destination.name + ".part")
        req = urllib.request.Request(spec.url, headers={"User-Agent": "N11-Minecraft/4.0"})
        try:
            with urllib.request.urlopen(req, timeout=60) as src, open(tmp, "wb") as dst:
                total = 0
                while True:
                    chunk = src.read(1024 * 1024)
                    if not chunk: break
                    dst.write(chunk); total += len(chunk)
            if spec.size is not None and total != spec.size:
                raise ValueError(f"size mismatch: {total} != {spec.size}")
            self.verify(tmp, spec)
            os.replace(tmp, spec.destination)
            return spec.destination
        finally:
            if tmp.exists() and not spec.destination.exists():
                tmp.unlink(missing_ok=True)

    def verify(self, path: Path, spec: DownloadSpec) -> None:
        if spec.sha1:
            h=hashlib.sha1();
            with open(path,"rb") as f:
                for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
            if h.hexdigest().lower()!=spec.sha1.lower(): raise ValueError("SHA-1 mismatch")
        if spec.sha256:
            h=hashlib.sha256();
            with open(path,"rb") as f:
                for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
            if h.hexdigest().lower()!=spec.sha256.lower(): raise ValueError("SHA-256 mismatch")
