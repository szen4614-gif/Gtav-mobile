from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class JavaRuntime:
    name: str
    version: str
    path: str
    abi: str = "arm64-v8a"

class RuntimeSelector:
    def select(self, runtimes: list[JavaRuntime], java_major: int = 21) -> JavaRuntime:
        candidates = [r for r in runtimes if r.abi == "arm64-v8a"]
        if not candidates:
            raise RuntimeError("No ARM64 Java runtime is installed")
        for runtime in candidates:
            major = runtime.version.split('.')[0].split('-')[0]
            if major == str(java_major): return runtime
        raise RuntimeError(f"No Java {java_major} ARM64 runtime is installed")
