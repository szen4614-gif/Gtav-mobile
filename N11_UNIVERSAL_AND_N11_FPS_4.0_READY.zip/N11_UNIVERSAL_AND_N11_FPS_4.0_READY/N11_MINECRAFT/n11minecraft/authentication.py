from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone

@dataclass(frozen=True)
class Session:
    username:str; uuid:str; access_token:str; expires_at:datetime

class AuthenticationProvider:
    """Provider boundary: production Microsoft OAuth/Xbox/Minecraft implementation is external-service work."""
    def validate(self, session:Session)->bool:
        return bool(session.username and session.uuid and session.access_token and session.expires_at>datetime.now(timezone.utc))
