from pathlib import Path

class GameDirectoryManager:
    def __init__(self, root: str | Path): self.root = Path(root)
    def path(self, child: str) -> Path:
        p = (self.root / child).resolve()
        if self.root.resolve() not in p.parents and p != self.root.resolve():
            raise ValueError("path escapes game directory")
        return p
