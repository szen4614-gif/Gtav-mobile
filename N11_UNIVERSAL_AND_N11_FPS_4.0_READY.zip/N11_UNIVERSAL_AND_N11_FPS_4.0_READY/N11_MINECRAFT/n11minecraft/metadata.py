from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

@dataclass(frozen=True)
class VersionEntry:
    id: str
    url: str
    type: str = "release"
    sha1: str | None = None

@dataclass
class VersionManifest:
    latest_release: str | None = None
    latest_snapshot: str | None = None
    versions: list[VersionEntry] = field(default_factory=list)

    @classmethod
    def from_json(cls, data: dict[str, Any]) -> "VersionManifest":
        latest = data.get("latest", {})
        versions = [VersionEntry(v["id"], v["url"], v.get("type", "release"), v.get("sha1")) for v in data.get("versions", [])]
        return cls(latest.get("release"), latest.get("snapshot"), versions)
