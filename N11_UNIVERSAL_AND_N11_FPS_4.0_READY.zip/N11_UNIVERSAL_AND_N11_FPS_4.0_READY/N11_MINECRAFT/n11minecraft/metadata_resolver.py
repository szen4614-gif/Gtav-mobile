from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json

@dataclass(frozen=True)
class LibraryArtifact:
    coordinate: str
    path: Path
    url: str | None = None
    sha1: str | None = None

class MinecraftMetadataResolver:
    """Resolves official-version JSON into artifacts; network transport stays in DownloadManager."""
    def resolve_version_json(self, path: Path) -> tuple[str, tuple[LibraryArtifact,...], str]:
        data=json.loads(path.read_text(encoding="utf-8"))
        libs=[]
        for lib in data.get("libraries",[]):
            art=lib.get("downloads",{}).get("artifact")
            if not art: continue
            libs.append(LibraryArtifact(lib.get("name",""), Path(art["path"]), art.get("url"), art.get("sha1")))
        main=data.get("mainClass","")
        return data.get("id",""), tuple(libs), main
