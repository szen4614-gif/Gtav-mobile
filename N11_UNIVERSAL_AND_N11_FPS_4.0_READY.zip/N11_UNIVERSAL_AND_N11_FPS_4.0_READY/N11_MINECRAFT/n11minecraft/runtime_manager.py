from __future__ import annotations
from pathlib import Path
import subprocess
from .runtime import JavaRuntime, RuntimeSelector

class RuntimeManager:
    def __init__(self, root:Path): self.root=root
    def discover(self)->list[JavaRuntime]:
        out=[]
        for java in self.root.glob("**/bin/java"):
            try: p=subprocess.run([str(java),"-version"],capture_output=True,text=True,timeout=5)
            except Exception: continue
            text=(p.stderr or p.stdout); version="unknown"
            import re
            m=re.search(r'version "([^"]+)',text)
            if m: version=m.group(1)
            out.append(JavaRuntime(java.parent.parent.name,version,str(java)))
        return out
    def select(self, major:int)->JavaRuntime: return RuntimeSelector().select(self.discover(),major)
