from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class AssetRef:
    name: str
    sha1: str
    size: int

class AssetIndex:
    def __init__(self, objects: dict[str, dict]):
        self.objects = {
            name: AssetRef(name, item["hash"], int(item["size"]))
            for name, item in objects.items()
        }

    @classmethod
    def from_json(cls, data: dict):
        return cls(data.get("objects", {}))

    def cache_path(self, root: str | Path, name: str) -> Path:
        obj = self.objects[name]
        return Path(root) / obj.sha1[:2] / obj.sha1
