from __future__ import annotations
from dataclasses import dataclass
import json, time, urllib.parse, urllib.request

CLIENT_ID="00000000402b5328"
MS_DEVICE="https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode"
MS_TOKEN="https://login.microsoftonline.com/consumers/oauth2/v2.0/token"
XBL="https://user.auth.xboxlive.com/user/authenticate"
XSTS="https://xsts.auth.xboxlive.com/xsts/authorize"
MC_LOGIN="https://api.minecraftservices.com/authentication/login_with_xbox"
MC_PROFILE="https://api.minecraftservices.com/minecraft/profile"

@dataclass(frozen=True)
class DeviceCode: device_code:str; user_code:str; verification_uri:str; expires_in:int; interval:int

class MicrosoftMinecraftAuth:
    def _post(self,url,data,headers=None):
        body=urllib.parse.urlencode(data).encode(); req=urllib.request.Request(url,body,headers=headers or {"Content-Type":"application/x-www-form-urlencoded"})
        with urllib.request.urlopen(req,timeout=30) as r: return json.loads(r.read())
    def begin(self)->DeviceCode:
        d=self._post(MS_DEVICE,{"client_id":CLIENT_ID,"scope":"service::user.auth.xboxlive.com::MBI_SSL offline_access"})
        return DeviceCode(d["device_code"],d["user_code"],d.get("verification_uri",d.get("verification_url")),int(d["expires_in"]),int(d.get("interval",5)))
    def poll(self,code:DeviceCode)->dict:
        deadline=time.time()+code.expires_in
        while time.time()<deadline:
            try:
                token=self._post(MS_TOKEN,{"grant_type":"urn:ietf:params:oauth:grant-type:device_code","client_id":CLIENT_ID,"device_code":code.device_code})
                if "access_token" in token: return token
            except Exception: pass
            time.sleep(code.interval)
        raise TimeoutError("Microsoft device login expired")
    def minecraft_profile(self,microsoft_access_token:str)->dict:
        x=self._post(XBL,{"Properties":{"AuthMethod":"RPS","SiteName":"user.auth.xboxlive.com","RpsTicket":"d="+microsoft_access_token},"RelyingParty":"http://auth.xboxlive.com","TokenType":"JWT"},{"Content-Type":"application/json"})
        xsts=self._post(XSTS,{"Properties":{"SandboxId":"RETAIL","UserTokens":[x["Token"]]},"RelyingParty":"rp://api.minecraftservices.com/","TokenType":"JWT"},{"Content-Type":"application/json"})
        uhs=xsts["DisplayClaims"]["xui"][0]["uhs"]
        mc=self._post(MC_LOGIN,{"identityToken":f"XBL3.0 x={uhs};{xsts['Token']}"},{"Content-Type":"application/json"})
        req=urllib.request.Request(MC_PROFILE,headers={"Authorization":"Bearer "+mc["access_token"]})
        with urllib.request.urlopen(req,timeout=30) as r: profile=json.loads(r.read())
        return {"access_token":mc["access_token"],"expires_in":mc.get("expires_in"),"profile":profile}
