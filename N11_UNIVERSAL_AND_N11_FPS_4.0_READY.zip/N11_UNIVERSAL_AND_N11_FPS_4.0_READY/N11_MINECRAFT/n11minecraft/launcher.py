from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Sequence

@dataclass(frozen=True)
class MinecraftLaunchPlan:
    game_dir: Path
    java_executable: Path
    main_class: str
    classpath: Sequence[Path] = field(default_factory=tuple)
    jvm_args: Sequence[str] = field(default_factory=tuple)
    game_args: Sequence[str] = field(default_factory=tuple)

    def command(self) -> list[str]:
        cmd=[str(self.java_executable), *self.jvm_args]
        if self.classpath: cmd += ["-cp", ":".join(map(str,self.classpath))]
        cmd += [self.main_class, *self.game_args]
        return cmd

class LauncherBackend:
    def build_plan(self, game_dir: Path, java_executable: Path, main_class: str,
                   classpath: Sequence[Path], jvm_args=(), game_args=()):
        return MinecraftLaunchPlan(game_dir, java_executable, main_class, classpath, jvm_args, game_args)
