from __future__ import annotations
from dataclasses import dataclass

SUPPORTED_LOADERS = ("fabric", "forge", "neoforge", "quilt")

@dataclass(frozen=True)
class ModSpec:
    id: str
    version: str
    loader: str
    url: str | None = None
    sha1: str | None = None

class ModLoaderRegistry:
    def resolve(self, loader: str) -> str:
        loader = loader.lower()
        if loader not in SUPPORTED_LOADERS:
            raise ValueError(f"unsupported loader: {loader}")
        return loader
