from __future__ import annotations
from pathlib import Path
import json, urllib.request

MANIFEST_URL="https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"

class MojangVersionService:
    def __init__(self, cache:Path): self.cache=cache
    def manifest(self)->dict:
        self.cache.parent.mkdir(parents=True,exist_ok=True)
        with urllib.request.urlopen(MANIFEST_URL,timeout=30) as r: data=json.load(r)
        self.cache.write_text(json.dumps(data,indent=2),encoding="utf-8"); return data
    def version_url(self,version:str)->str:
        data=json.loads(self.cache.read_text(encoding="utf-8")) if self.cache.exists() else self.manifest()
        for v in data.get("versions",[]):
            if v.get("id")==version: return v["url"]
        raise KeyError(version)
    def fetch_version(self,version:str,out:Path)->Path:
        out.parent.mkdir(parents=True,exist_ok=True)
        with urllib.request.urlopen(self.version_url(version),timeout=30) as r: out.write_bytes(r.read())
        return out
