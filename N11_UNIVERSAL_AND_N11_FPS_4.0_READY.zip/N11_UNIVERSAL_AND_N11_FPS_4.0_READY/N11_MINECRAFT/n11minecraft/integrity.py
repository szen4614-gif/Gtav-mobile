from __future__ import annotations
import hashlib
from pathlib import Path


def sha1_file(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha1()
    with Path(path).open("rb") as f:
        while chunk := f.read(chunk_size):
            h.update(chunk)
    return h.hexdigest()


def verify_sha1(path: str | Path, expected: str) -> bool:
    return sha1_file(path).lower() == expected.lower()
