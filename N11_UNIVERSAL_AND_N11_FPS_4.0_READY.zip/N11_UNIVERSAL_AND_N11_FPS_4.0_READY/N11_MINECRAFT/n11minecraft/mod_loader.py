from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path

SUPPORTED=("vanilla","fabric","forge","neoforge","quilt")
@dataclass(frozen=True)
class ModLoaderProfile:
    kind:str
    version:str
    mods_dir:Path

class ModLoaderManager:
    def create(self,kind:str,version:str,game_dir:Path)->ModLoaderProfile:
        kind=kind.lower()
        if kind not in SUPPORTED: raise ValueError(f"Unsupported loader: {kind}")
        p=game_dir/"mods"; p.mkdir(parents=True,exist_ok=True)
        return ModLoaderProfile(kind,version,p)
