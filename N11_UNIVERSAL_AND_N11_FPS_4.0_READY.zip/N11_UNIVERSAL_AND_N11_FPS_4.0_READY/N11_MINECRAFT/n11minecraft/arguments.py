from __future__ import annotations
from pathlib import Path
import json, re, platform

def _rules_allow(rules):
    if not rules: return True
    allowed=False
    for r in rules:
        os_rule=r.get("os",{})
        if "name" in os_rule and os_rule["name"] not in ("linux", "android"): continue
        if "arch" in os_rule and os_rule["arch"] not in (platform.machine(), "aarch64", "arm64"): continue
        if r.get("action")=="disallow": return False
        if r.get("action")=="allow": allowed=True
    return allowed

def expand(value:str, variables:dict[str,str])->str:
    return re.sub(r"\$\{([^}]+)\}", lambda m:variables.get(m.group(1),m.group(0)), value)

def resolve_arguments(entries, variables):
    out=[]
    for entry in entries or []:
        if isinstance(entry,str): out.append(expand(entry,variables)); continue
        if not _rules_allow(entry.get("rules")): continue
        value=entry.get("value","")
        values=value if isinstance(value,list) else [value]
        out.extend(expand(str(v),variables) for v in values)
    return out
