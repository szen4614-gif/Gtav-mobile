from dataclasses import dataclass

@dataclass
class ShaderManager:
    cache_dir: str
    enabled: bool = True

    def select(self, shader_pack: str | None):
        if not self.enabled: return None
        return shader_pack
