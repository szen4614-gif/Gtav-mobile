from dataclasses import dataclass

@dataclass(frozen=True)
class RendererCapabilities:
    opengl_es: bool = True
    vulkan: bool = False
    gl4es: bool = False
    shader_cache: bool = True

class RendererBackend:
    name = "abstract"
    def capabilities(self) -> RendererCapabilities:
        return RendererCapabilities()

class OpenGLESBackend(RendererBackend): name = "opengles"
class VulkanBackend(RendererBackend):
    name = "vulkan"
    def capabilities(self): return RendererCapabilities(vulkan=True)
class GL4ESBackend(RendererBackend):
    name = "gl4es"
    def capabilities(self): return RendererCapabilities(gl4es=True)
