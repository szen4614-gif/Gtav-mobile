from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import subprocess, threading, time

@dataclass
class ProcessResult:
    returncode:int
    duration:float

class MinecraftProcessSupervisor:
    def __init__(self): self.process=None
    def start(self, command:list[str], cwd:Path, env:dict[str,str]|None=None):
        if self.process and self.process.poll() is None: raise RuntimeError("Minecraft is already running")
        self.process=subprocess.Popen(command,cwd=str(cwd),env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
        return self.process
    def stream(self, callback):
        if not self.process or not self.process.stdout: return
        for line in self.process.stdout: callback(line.rstrip("\n"))
    def wait(self)->ProcessResult:
        if not self.process: raise RuntimeError("No process")
        t=time.monotonic(); code=self.process.wait(); return ProcessResult(code,time.monotonic()-t)
    def terminate(self):
        if self.process and self.process.poll() is None: self.process.terminate()
