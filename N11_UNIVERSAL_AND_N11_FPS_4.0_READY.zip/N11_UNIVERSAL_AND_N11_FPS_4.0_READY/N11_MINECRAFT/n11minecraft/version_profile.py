from __future__ import annotations
from dataclasses import dataclass, field

@dataclass
class VersionProfile:
    id: str
    main_class: str
    java_major: int = 21
    jvm_args: list[str] = field(default_factory=list)
    game_args: list[str] = field(default_factory=list)

    @classmethod
    def from_json(cls, data: dict):
        java_major = int(data.get("javaVersion", {}).get("majorVersion", 21))
        return cls(data.get("id", "unknown"), data.get("mainClass", ""), java_major)
