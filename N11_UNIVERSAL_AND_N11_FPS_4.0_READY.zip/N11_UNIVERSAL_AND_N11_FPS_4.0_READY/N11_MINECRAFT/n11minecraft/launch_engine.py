from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json
from .launcher import MinecraftLaunchPlan
from .classpath import ClasspathBuilder
from .metadata_resolver import MinecraftMetadataResolver
from .arguments import resolve_arguments

@dataclass(frozen=True)
class LaunchRequest:
    version:str; game_dir:Path; java:Path; client_jar:Path; version_json:Path; libraries_root:Path
    username:str; uuid:str; access_token:str; assets_root:Path|None=None; natives_dir:Path|None=None
    width:int=1280; height:int=720

class N11LaunchEngine:
    def build(self, req:LaunchRequest)->MinecraftLaunchPlan:
        data=json.loads(req.version_json.read_text(encoding="utf-8"))
        version=data.get("id","")
        if version != req.version: raise ValueError(f"Metadata/version mismatch: {version} != {req.version}")
        libs=[]
        for lib in data.get("libraries",[]):
            art=lib.get("downloads",{}).get("artifact")
            if art: libs.append(type("A",(),{"path":Path(art["path"])})())
        cp=ClasspathBuilder().build(libs,req.libraries_root,req.client_jar)
        if not cp: raise RuntimeError("No Minecraft classpath artifacts are installed")
        vars={"auth_player_name":req.username,"auth_uuid":req.uuid,"auth_access_token":req.access_token,
              "version_name":req.version,"game_directory":str(req.game_dir),"assets_root":str(req.assets_root or req.game_dir/"assets"),
              "assets_index_name":str(data.get("assetIndex",{}).get("id","")),"natives_directory":str(req.natives_dir or req.game_dir/"natives"),
              "classpath":str(Path(":".join(map(str,cp))))}
        args=data.get("arguments",{})
        game_args=resolve_arguments(args.get("game"),vars) if isinstance(args,dict) and args.get("game") else []
        if not game_args and data.get("minecraftArguments"):
            game_args=data["minecraftArguments"].split()
        game_args=[a.replace("${auth_player_name}",req.username).replace("${auth_uuid}",req.uuid).replace("${auth_access_token}",req.access_token) for a in game_args]
        jvm_args=resolve_arguments(args.get("jvm"),vars) if isinstance(args,dict) else []
        return MinecraftLaunchPlan(req.game_dir,req.java,data.get("mainClass", "net.minecraft.client.main.Main"),tuple(cp),tuple(jvm_args),tuple(game_args))
