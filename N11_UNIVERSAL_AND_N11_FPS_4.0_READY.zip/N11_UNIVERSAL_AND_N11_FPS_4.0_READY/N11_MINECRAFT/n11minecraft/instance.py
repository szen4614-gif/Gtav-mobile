from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class MinecraftInstance:
    name:str; root:Path; version:str; loader:str="vanilla"; java_major:int=17

class InstanceManager:
    def create(self,root:Path,name:str,version:str,loader="vanilla",java_major=17)->MinecraftInstance:
        p=root/name; (p/"mods").mkdir(parents=True,exist_ok=True); (p/"resourcepacks").mkdir(exist_ok=True); (p/"shaderpacks").mkdir(exist_ok=True)
        return MinecraftInstance(name,p,version,loader,java_major)
