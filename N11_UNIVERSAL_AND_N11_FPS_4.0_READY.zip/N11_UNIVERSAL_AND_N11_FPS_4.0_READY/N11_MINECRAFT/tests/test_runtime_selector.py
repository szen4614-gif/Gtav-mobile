import pytest
from n11minecraft.runtime import JavaRuntime, RuntimeSelector

def test_runtime_selector_exact_major():
    r=RuntimeSelector().select([JavaRuntime('j17','17.0.1','/j17')],17)
    assert r.name=='j17'
    with pytest.raises(RuntimeError): RuntimeSelector().select([r],8)
