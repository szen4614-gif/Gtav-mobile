import json
from pathlib import Path
from n11minecraft.arguments import resolve_arguments
from n11minecraft.runtime_manifest import RUNTIMES

def test_modern_argument_rules():
    assert resolve_arguments(["-Dfoo=${bar}", {"rules":[{"action":"allow","os":{"name":"linux"}}],"value":"-Dok=1"}], {"bar":"ok"}) == ["-Dfoo=ok","-Dok=1"]

def test_runtime_hashes_are_pinned():
    assert all(len(r.sha256)==64 and set(r.sha256)<=set('0123456789abcdef') for r in RUNTIMES if r.major in (17,21,25))

def test_component_manifest_is_real():
    p=Path(__file__).parents[2]/"N11_ANDROID/app/src/main/assets/n11/components.json"
    data=json.loads(p.read_text())
    assert data["architecture"]=="arm64-v8a"
    assert all(x["url"].startswith("https://") for x in data["runtimes"])
