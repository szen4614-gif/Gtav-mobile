from pathlib import Path
from n11minecraft.assets import AssetIndex
from n11minecraft.launcher import LauncherBackend
from n11minecraft.runtime import JavaRuntime, RuntimeSelector
from n11minecraft.storage import GameDirectoryManager
from n11minecraft.version_profile import VersionProfile

def test_runtime_selector():
    r = RuntimeSelector().select([JavaRuntime("a", "21.0.0", "/java")])
    assert r.abi == "arm64-v8a"

def test_launcher_command():
    plan = LauncherBackend().build_plan(Path("/game"), Path("/java"), "Main", [Path("a.jar")])
    assert plan.command()[:3] == ["/java", "-cp", "a.jar"]

def test_storage_sandbox():
    g = GameDirectoryManager("/tmp/n11-game")
    assert str(g.path("saves/world")).endswith("/saves/world")

def test_assets_and_version_profile():
    index = AssetIndex.from_json({"objects": {"a": {"hash": "abcdef", "size": 6}}})
    assert index.cache_path("/cache", "a").name == "abcdef"
    p = VersionProfile.from_json({"id": "demo", "mainClass": "Main", "javaVersion": {"majorVersion": 21}})
    assert p.java_major == 21
