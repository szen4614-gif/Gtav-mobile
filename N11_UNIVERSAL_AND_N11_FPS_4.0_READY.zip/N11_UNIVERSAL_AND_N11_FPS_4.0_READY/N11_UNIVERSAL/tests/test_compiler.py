from n11lang.compiler import compile_source
from n11lang.runtime import Runtime

def test_hello():
    m=compile_source('module x fn main() { let a = 7; print a; return a; }')
    r=Runtime(); r.register(m)
    assert r.run("x") == 7

def test_fps_provider():
    m=compile_source('module x fn main() { let a = fps(); return a; }')
    r=Runtime(fps_provider=lambda: 144.0); r.register(m)
    assert r.run("x") == 144.0
