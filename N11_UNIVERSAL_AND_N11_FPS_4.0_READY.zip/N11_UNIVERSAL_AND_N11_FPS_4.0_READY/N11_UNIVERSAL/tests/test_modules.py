from n11lang.module_system import ModuleRegistry, NativeModule

def test_native_module_registry():
    r = ModuleRegistry()
    m = NativeModule("demo", "1", {"add": lambda a, b: a+b})
    r.register(m)
    assert r.get("demo").call("add", 2, 3) == 5
