# N11 Universal

N11 Universal is the independent programming/runtime side of the N11
ecosystem.

It is designed to run by itself, while exposing a stable integration
boundary for optional systems such as N11 FPS.

## Design

N11 source -\> lexer/parser -\> semantic validation -\> Universal IR -\>
runtime/backend.

The package intentionally has a small, real executable core instead of
claiming that every cataloged subsystem is already production-grade.

## Included

-   N11 source parser for modules, functions, `let`, `print`, `return`,
    calls and basic arithmetic.
-   Typed Universal IR.
-   Deterministic interpreter runtime.
-   CLI. 
-   N11 FPS integration API.
-   Tests.
-   Explicit capability/status metadata.

## Independent use

``` text
N11_UNIVERSAL/
  works without N11 FPS
```

## Combined use

``` text
N11_UNIVERSAL -> N11 FPS adapter
```

N11 Universal does not require N11 FPS to compile or run ordinary
programs.

## Status rule

CONCEPT -\> SPECIFIED -\> PROTOTYPE -\> IMPLEMENTED -\> INTEGRATED -\>
VALIDATED -\> PRODUCTION

Only code that is actually present and tested is marked
implemented/validated.
