# N11 Universal Architecture

## Boundary

N11 Universal owns language semantics, IR and execution.

N11 FPS owns performance intelligence.

The integration boundary is deliberately optional:

``` text
N11 Universal
    |
    | optional provider
    v
N11 FPS
```

## Contract

The universal runtime may ask for:

-   current measured FPS;
-   frame time;
-   performance profile;
-   optimization recommendation.

It must not assume a specific vendor GPU or a specific optimization
backend.
