import argparse
from pathlib import Path
from .compiler import compile_source
from .runtime import Runtime

def main():
    p=argparse.ArgumentParser(prog="n11")
    p.add_argument("file")
    ns=p.parse_args()
    src=Path(ns.file).read_text(encoding="utf-8")
    mod=compile_source(src)
    rt=Runtime(); rt.register(mod); rt.run(mod.name)

if __name__ == "__main__":
    main()
