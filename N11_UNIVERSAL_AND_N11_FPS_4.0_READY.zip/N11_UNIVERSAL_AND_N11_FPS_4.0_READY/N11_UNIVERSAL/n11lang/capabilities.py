from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

@dataclass(frozen=True)
class Capability:
    name: str
    status: str
    owner: str
    details: str = ""

@dataclass
class CapabilityRegistry:
    entries: dict[str, Capability] = field(default_factory=dict)

    def register(self, name: str, status: str, owner: str, details: str = "") -> Capability:
        cap = Capability(name, status, owner, details)
        self.entries[name] = cap
        return cap

    def status(self, name: str) -> str | None:
        cap = self.entries.get(name)
        return cap.status if cap else None

    def snapshot(self) -> dict[str, dict[str, Any]]:
        return {
            name: {"status": c.status, "owner": c.owner, "details": c.details}
            for name, c in sorted(self.entries.items())
        }

    def require(self, name: str, allowed=("IMPLEMENTED", "INTEGRATED")) -> Capability:
        cap = self.entries[name]
        if cap.status not in allowed:
            raise RuntimeError(f"capability {name!r} is {cap.status}, not ready")
        return cap
