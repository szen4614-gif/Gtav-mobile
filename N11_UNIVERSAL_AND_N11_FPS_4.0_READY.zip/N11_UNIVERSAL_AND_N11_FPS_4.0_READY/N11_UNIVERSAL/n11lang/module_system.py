from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, Any

@dataclass
class NativeModule:
    name: str
    version: str
    exports: dict[str, Callable[..., Any]] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def call(self, symbol: str, *args, **kwargs):
        if symbol not in self.exports:
            raise KeyError(f"{self.name}: unknown symbol {symbol}")
        return self.exports[symbol](*args, **kwargs)

@dataclass
class ModuleRegistry:
    modules: dict[str, NativeModule] = field(default_factory=dict)

    def register(self, module: NativeModule) -> None:
        if module.name in self.modules:
            raise ValueError(f"module already registered: {module.name}")
        self.modules[module.name] = module

    def get(self, name: str) -> NativeModule:
        return self.modules[name]
