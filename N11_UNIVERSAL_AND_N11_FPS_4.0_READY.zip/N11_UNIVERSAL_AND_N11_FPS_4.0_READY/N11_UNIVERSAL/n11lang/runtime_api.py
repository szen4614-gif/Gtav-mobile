"""Stable host API used by platform integrations."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable

@dataclass
class RuntimeContext:
    values: dict[str, Any] = field(default_factory=dict)
    providers: dict[str, Callable[..., Any]] = field(default_factory=dict)

    def provide(self, name: str, fn: Callable[..., Any]) -> None:
        self.providers[name] = fn

    def call(self, name: str, *args, **kwargs) -> Any:
        return self.providers[name](*args, **kwargs)
