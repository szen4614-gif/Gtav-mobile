import re
from .ir import ModuleIR, FunctionIR, Instruction

TOKEN = re.compile(r'\s*(?:(\d+(?:\.\d+)?)|(".*?")|([A-Za-z_]\w*)|(.))', re.S)

def tokenize(src):
    out=[]
    for m in TOKEN.finditer(src):
        num, string, ident, sym = m.groups()
        if num: out.append(("num", num))
        elif string: out.append(("str", string[1:-1]))
        elif ident: out.append(("id", ident))
        elif sym: out.append((sym, sym))
    return out

class Parser:
    def __init__(self, src):
        self.t = tokenize(src); self.i = 0

    def peek(self, value=None):
        if self.i >= len(self.t): return False if value else None
        return self.t[self.i][1] == value if value else self.t[self.i]

    def pop(self, value=None):
        if self.i >= len(self.t): raise SyntaxError("unexpected end of input")
        tok=self.t[self.i]
        if value is not None and tok[1] != value:
            raise SyntaxError(f"expected {value!r}, got {tok[1]!r}")
        self.i += 1
        return tok

    def parse(self):
        self.pop("module")
        name=self.pop()[1]
        funcs={}
        while self.i < len(self.t):
            self.pop("fn")
            fn=self.pop()[1]
            self.pop("(")
            params=[]
            if not self.peek(")"):
                while True:
                    params.append(self.pop()[1])
                    if self.peek(","): self.pop(","); continue
                    break
            self.pop(")")
            self.pop("{")
            code=[]
            while not self.peek("}"):
                code += self.statement()
            self.pop("}")
            funcs[fn]=FunctionIR(fn, params, code)
        return ModuleIR(name, funcs)

    def expression(self):
        tok=self.pop()
        if tok[0] in ("num","str"): return [Instruction("const",[float(tok[1]) if tok[0]=="num" and "." in tok[1] else int(tok[1]) if tok[0]=="num" else tok[1]])]
        if tok[1] == "fps":
            if self.peek("("):
                self.pop("("); self.pop(")")
            return [Instruction("fps_get",[])]
        if tok[0] == "id":
            if self.peek("("):
                self.pop("("); args=[]
                if not self.peek(")"):
                    args=self.expression()
                    while self.peek(","):
                        self.pop(","); args += self.expression()
                self.pop(")")
                return args+[Instruction("call",[tok[1], len(args)])]
            return [Instruction("load",[tok[1]])]
        raise SyntaxError(f"bad expression: {tok}")

    def statement(self):
        if self.peek("let"):
            self.pop("let"); name=self.pop()[1]; self.pop("=")
            code=self.expression()
            self.pop(";"); return code+[Instruction("store",[name])]
        if self.peek("print"):
            self.pop("print"); code=self.expression(); self.pop(";")
            return code+[Instruction("print")]
        if self.peek("return"):
            self.pop("return"); code=self.expression(); self.pop(";")
            return code+[Instruction("return")]
        raise SyntaxError(f"unknown statement near {self.peek()}")

def compile_source(src):
    return Parser(src).parse()
