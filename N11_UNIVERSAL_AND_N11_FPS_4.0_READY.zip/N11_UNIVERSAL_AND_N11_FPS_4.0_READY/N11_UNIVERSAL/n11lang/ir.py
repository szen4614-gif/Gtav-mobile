from dataclasses import dataclass, field
from typing import Any

@dataclass
class Instruction:
    op: str
    args: list[Any] = field(default_factory=list)

@dataclass
class FunctionIR:
    name: str
    params: list[str]
    code: list[Instruction]

@dataclass
class ModuleIR:
    name: str
    functions: dict[str, FunctionIR]

    def entry(self):
        return self.functions.get("main")
