from .ir import ModuleIR

class Runtime:
    def __init__(self, modules=None, fps_provider=None):
        self.modules = modules or {}
        self.fps_provider = fps_provider
        self.stdout = []

    def register(self, module: ModuleIR):
        self.modules[module.name] = module

    def run(self, module_name, entry="main", args=None):
        module = self.modules[module_name]
        fn = module.functions[entry]
        env = dict(zip(fn.params, args or []))
        stack=[]
        pc=0
        while pc < len(fn.code):
            ins=fn.code[pc]; pc += 1
            if ins.op == "const": stack.append(ins.args[0])
            elif ins.op == "load": stack.append(env[ins.args[0]])
            elif ins.op == "store": env[ins.args[0]]=stack.pop()
            elif ins.op == "print":
                value=stack.pop(); self.stdout.append(str(value)); print(value)
            elif ins.op == "fps_get":
                value = self.fps_provider() if self.fps_provider else 0.0
                stack.append(value)
            elif ins.op == "call":
                name, n=ins.args
                vals=stack[-n:] if n else []
                if n: del stack[-n:]
                if name == "max": stack.append(max(vals))
                elif name == "min": stack.append(min(vals))
                elif name == "add": stack.append(vals[0]+vals[1])
                else: raise RuntimeError(f"unknown builtin: {name}")
            elif ins.op == "return":
                return stack.pop() if stack else None
            else:
                raise RuntimeError(f"unknown opcode: {ins.op}")
        return None
