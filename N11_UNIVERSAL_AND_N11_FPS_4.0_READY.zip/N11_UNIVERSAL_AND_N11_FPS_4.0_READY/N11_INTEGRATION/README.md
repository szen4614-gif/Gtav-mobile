# N11 Integration

This folder documents and demonstrates the fact that the two packages
remain independent but composable.

``` text
N11 Universal
      |
      | optional provider
      v
N11 FPS
```

Neither package needs the other to start.

The bridge uses a narrow provider interface so the language/runtime does
not become coupled to Android, Vulkan, a GPU vendor, or a cloud
provider.
