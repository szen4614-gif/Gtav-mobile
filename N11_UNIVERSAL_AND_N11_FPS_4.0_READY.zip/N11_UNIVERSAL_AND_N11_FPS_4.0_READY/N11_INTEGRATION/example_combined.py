from n11lang.compiler import compile_source
from n11lang.runtime import Runtime
from n11fps.core import PerformanceEngine
from n11fps.integration import FPSProvider
from n11fps.models import Telemetry

engine = PerformanceEngine()
provider = FPSProvider(
    engine,
    lambda: Telemetry(fps=144.0, frame_ms=6.94, gpu_util=72, cpu_util=48)
)

program = compile_source('''
module combined
fn main() {
    let current = fps();
    print current;
    return current;
}
''')

runtime = Runtime(fps_provider=provider)
runtime.register(program)
runtime.run("combined")
