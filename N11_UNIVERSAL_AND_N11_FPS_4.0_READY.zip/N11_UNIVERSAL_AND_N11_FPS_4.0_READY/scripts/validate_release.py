from __future__ import annotations
import json, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "N11_UNIVERSAL/n11lang/runtime.py",
    "N11_UNIVERSAL/n11lang/module_system.py",
    "N11_FPS/n11fps/core.py",
    "N11_FPS/n11fps/adaptive.py",
    "N11_ANDROID/settings.gradle.kts",
    "N11_ANDROID/app/src/main/kotlin/com/n11/minecraft/bridge/N11AndroidBridge.kt",
    "N11_ANDROID/app/src/main/cpp/n11runtime.cpp",
    "N11_MINECRAFT/n11minecraft/launcher.py",
    "N11_PLATFORM/capability_status.json",
]

def main():
    missing = [x for x in REQUIRED if not (ROOT/x).is_file()]
    if missing:
        print("MISSING:")
        print("\n".join(missing))
        return 2
    data = json.loads((ROOT/"MANIFEST.json").read_text())
    assert data["targets"]["abi"] == ["arm64-v8a"]
    env = {"PYTHONPATH": ":".join([str(ROOT/"N11_UNIVERSAL"), str(ROOT/"N11_FPS"), str(ROOT/"N11_MINECRAFT")])}
    print("N11 release structure: OK")
    print("Manifest targets: API", data["targets"]["android_target_sdk"], "ABI", data["targets"]["abi"])
    return 0

if __name__ == "__main__": raise SystemExit(main())
