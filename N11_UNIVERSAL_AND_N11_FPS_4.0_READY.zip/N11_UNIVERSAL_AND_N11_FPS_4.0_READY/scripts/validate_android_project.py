from pathlib import Path
import json, re, sys

root = Path(__file__).resolve().parents[1]
android = root / "N11_ANDROID"
checks = {
    "root build": android / "build.gradle.kts",
    "app build": android / "app/build.gradle.kts",
    "manifest": android / "app/src/main/AndroidManifest.xml",
    "native cmake": android / "app/src/main/cpp/CMakeLists.txt",
    "bridge": android / "app/src/main/kotlin/com/n11/minecraft/bridge/N11AndroidBridge.kt",
    "runtime installer": android / "app/src/main/kotlin/com/n11/minecraft/runtime/N11RuntimeInstaller.kt",
    "minecraft repo": android / "app/src/main/kotlin/com/n11/minecraft/minecraft/N11MinecraftRepository.kt",
    "components": android / "app/src/main/assets/n11/components.json",
}
missing = [name for name, p in checks.items() if not p.is_file()]
if missing:
    raise SystemExit("Missing: " + ", ".join(missing))

build = (android / "build.gradle.kts").read_text()
app = (android / "app/build.gradle.kts").read_text()
wrapper = (android / "gradle/wrapper/gradle-wrapper.properties").read_text()
cmake = (android / "app/src/main/cpp/CMakeLists.txt").read_text()
assert 'version "9.2.0"' in build
assert 'version "2.2.10"' in build
assert 'gradle-9.4.1-bin.zip' in wrapper
assert 'ndkVersion = "28.2.13676358"' in app
assert 'arm64-v8a' in app
assert 'max-page-size=16384' in cmake and 'common-page-size=16384' in cmake
components = json.loads((android / "app/src/main/assets/n11/components.json").read_text())
majors = {x["major"] for x in components["runtimes"]}
assert {8,17,21,25}.issubset(majors)
for runtime in components["runtimes"]:
    assert re.fullmatch(r"[0-9a-f]{64}", runtime["sha256"])
print("N11 Android source validation: OK")
