#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PYTHONPATH="$ROOT/N11_UNIVERSAL:$ROOT/N11_FPS:$ROOT/N11_MINECRAFT"
python -m pytest -q "$ROOT/N11_UNIVERSAL/tests" "$ROOT/N11_FPS/tests" "$ROOT/N11_MINECRAFT/tests"
python "$ROOT/scripts/validate_release.py"
