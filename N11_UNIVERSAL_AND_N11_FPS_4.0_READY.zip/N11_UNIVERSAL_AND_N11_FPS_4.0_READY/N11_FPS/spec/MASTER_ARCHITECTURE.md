# N11 FPS Master Architecture

## Core loop

OBSERVE -\> UNDERSTAND -\> DIAGNOSE -\> PLAN -\> EXECUTE -\> MEASURE -\>
LEARN

## Optimization order

ELIMINATE -\> REUSE -\> PREDICT -\> PARALLELIZE -\> SPECIALIZE -\>
COMPRESS -\> MOVE -\> RECONSTRUCT -\> ADAPT -\> QUALITY REDUCTION

## Domains

-   games
-   launchers
-   applications
-   cloud gaming
-   media
-   servers
-   development workloads

## Integration

N11 FPS never owns application truth. It can optimize representation and
execution, but authoritative game/application state remains with the
host system.
