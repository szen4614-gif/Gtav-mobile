from __future__ import annotations

MOTO_G15 = {
    "name": "Motorola moto g15",
    "os": "Android 15",
    "soc": "MediaTek Helio G81 Extreme",
    "cpu": "octa-core; up to 2.0 GHz",
    "gpu": "Arm Mali-G52 MC2",
    "ram_options_gb": [4, 8],
    "display_hz": 60,
    "abi": "arm64-v8a",
    "tuning": {
        "default_target_fps": 60,
        "max_render_scale": 1.0,
        "thermal_start_c": 42.0,
        "thermal_reduce_c": 44.0,
        "memory_pressure_pct": 85.0,
        "prefer_async_asset_loading": True,
        "prefer_shader_cache": True
    }
}

def profile_for(model: str = "moto g15"):
    if model.lower().replace("motorola ", "") == "moto g15":
        return MOTO_G15.copy()
    return {"name": model, "abi": "arm64-v8a", "tuning": {}}
