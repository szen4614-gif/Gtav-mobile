from .models import Telemetry, Recommendation

class BottleneckOracle:
    def diagnose(self, t: Telemetry):
        scores = {
            "gpu": t.gpu_util + max(0, t.frame_ms-16.67)*2,
            "cpu": t.cpu_util,
            "npu": t.npu_util,
            "memory": t.memory_util,
            "network": min(100, t.network_rtt_ms + t.jitter_ms*2 + t.packet_loss*100),
            "encoder": t.encode_ms*10,
            "decoder": t.decode_ms*10,
        }
        name=max(scores, key=scores.get)
        return name, scores[name]

    def recommend(self, t: Telemetry):
        name, score=self.diagnose(t)
        if name == "gpu":
            return Recommendation("reuse_or_reduce_gpu_work", "GPU/frame-time pressure detected")
        if name == "cpu":
            return Recommendation("parallelize_or_reduce_cpu_work", "CPU pressure detected")
        if name == "network":
            return Recommendation("adapt_stream", "network latency/jitter/loss is dominant")
        if name == "encoder":
            return Recommendation("switch_or_tune_encoder", "encoder latency is significant")
        if name == "decoder":
            return Recommendation("switch_or_tune_decoder", "decoder latency is significant")
        if name == "memory":
            return Recommendation("reduce_memory_pressure", "memory pressure detected")
        return Recommendation("observe", "no dominant bottleneck detected")
