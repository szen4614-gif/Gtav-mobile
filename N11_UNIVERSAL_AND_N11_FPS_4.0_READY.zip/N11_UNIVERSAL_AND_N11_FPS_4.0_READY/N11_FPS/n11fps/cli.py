import argparse, json
from .core import PerformanceEngine
from .models import Telemetry

def main():
    p=argparse.ArgumentParser(prog="n11-fps")
    sub=p.add_subparsers(dest="cmd")
    sub.add_parser("inspect")
    obs=sub.add_parser("diagnose")
    obs.add_argument("--gpu",type=float,default=95)
    obs.add_argument("--cpu",type=float,default=40)
    obs.add_argument("--fps",type=float,default=60)
    obs.add_argument("--frame-ms",type=float,default=16.67)
    ns=p.parse_args()
    if ns.cmd=="inspect":
        print(json.dumps(PerformanceEngine().profile("balanced").targets, indent=2))
        return
    if ns.cmd=="diagnose":
        t=Telemetry(gpu_util=ns.gpu,cpu_util=ns.cpu,fps=ns.fps,frame_ms=ns.frame_ms)
        print(PerformanceEngine().observe(t))
        return
    p.print_help()

if __name__=="__main__":
    main()
