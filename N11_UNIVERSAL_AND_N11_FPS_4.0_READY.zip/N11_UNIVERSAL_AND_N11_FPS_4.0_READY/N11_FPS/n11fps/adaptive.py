from __future__ import annotations
from dataclasses import dataclass
from .models import Telemetry, PerformanceProfile

@dataclass(frozen=True)
class AdaptiveDecision:
    action: str
    reason: str
    target_fps: float
    quality: float

class AdaptiveController:
    """Conservative controller: it only changes a tunable budget, never the OS."""
    def decide(self, telemetry: Telemetry, profile: PerformanceProfile) -> AdaptiveDecision:
        target = float(profile.targets.get("target_fps", 60.0))
        floor = float(profile.targets.get("quality_floor", 0.90))
        if telemetry.temperature_c is not None and telemetry.temperature_c >= 44:
            return AdaptiveDecision("reduce_work", "thermal budget pressure", max(30.0, target - 5), floor)
        if telemetry.frame_ms > 1000.0 / target * 1.15:
            return AdaptiveDecision("reduce_work", "frame-time above target budget", target, floor)
        if telemetry.gpu_util > 92 and telemetry.cpu_util < 70:
            return AdaptiveDecision("reuse_gpu_work", "GPU saturation dominates", target, floor)
        if telemetry.cpu_util > 92 and telemetry.gpu_util < 75:
            return AdaptiveDecision("parallelize_or_reduce_cpu_work", "CPU saturation dominates", target, floor)
        return AdaptiveDecision("hold", "within configured performance budget", target, floor)
