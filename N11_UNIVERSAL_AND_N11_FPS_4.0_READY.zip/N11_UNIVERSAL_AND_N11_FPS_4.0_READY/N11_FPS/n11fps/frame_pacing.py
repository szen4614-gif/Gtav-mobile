from __future__ import annotations
from dataclasses import dataclass

@dataclass
class FramePacer:
    target_fps: float = 60.0
    vsync: bool = True

    @property
    def budget_ms(self) -> float:
        return 1000.0 / self.target_fps if self.target_fps > 0 else 16.67

    def classify(self, frame_ms: float) -> str:
        if frame_ms <= self.budget_ms * 0.95:
            return "ahead"
        if frame_ms <= self.budget_ms * 1.05:
            return "on_budget"
        if frame_ms <= self.budget_ms * 1.25:
            return "late"
        return "severely_late"
