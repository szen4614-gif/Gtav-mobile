from dataclasses import dataclass, asdict

@dataclass
class HardwareProfile:
    cpu: str = "unknown"
    gpu: str = "unknown"
    npu: str = "unknown"
    memory_gb: float = 0.0
    os: str = "unknown"
    vulkan: bool = False
    hardware_video_decode: bool = False
    hardware_video_encode: bool = False

    def capabilities(self):
        return asdict(self)
