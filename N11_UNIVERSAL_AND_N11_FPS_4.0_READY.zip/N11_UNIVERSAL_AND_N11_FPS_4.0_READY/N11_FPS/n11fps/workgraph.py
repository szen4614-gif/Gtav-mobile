from dataclasses import dataclass, field

@dataclass
class WorkNode:
    name: str
    cost_ms: float = 0.0
    reusable: bool = False
    predictable: bool = False
    dependencies: list[str] = field(default_factory=list)

class UniversalWorkGraph:
    def __init__(self):
        self.nodes={}

    def add(self, node: WorkNode):
        self.nodes[node.name]=node

    def optimize(self):
        actions=[]
        for n in self.nodes.values():
            if n.reusable: actions.append((n.name, "reuse"))
            elif n.predictable: actions.append((n.name, "prefetch/predict"))
            else: actions.append((n.name, "execute"))
        return actions
