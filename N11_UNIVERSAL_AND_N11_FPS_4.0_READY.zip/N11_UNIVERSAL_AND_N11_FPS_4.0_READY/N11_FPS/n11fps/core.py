from .models import Telemetry, QualityBudget, PerformanceProfile
from .bottleneck import BottleneckOracle
from .quality import QualityShield
from .adaptive import AdaptiveController

class PerformanceEngine:
    def __init__(self, quality=None):
        self.quality = quality or QualityBudget()
        self.oracle = BottleneckOracle()
        self.shield = QualityShield(self.quality)
        self.adaptive = AdaptiveController()
        self.history = []

    def observe(self, telemetry: Telemetry):
        self.history.append(telemetry)
        if len(self.history) > 256:
            self.history.pop(0)
        name, score = self.oracle.diagnose(telemetry)
        rec = self.oracle.recommend(telemetry)
        decision = self.adaptive.decide(telemetry, self.profile("balanced"))
        return {"bottleneck": name, "score": score, "recommendation": rec, "adaptive": decision}

    def fps(self, telemetry: Telemetry):
        return telemetry.fps

    def profile(self, name="balanced"):
        presets = {
            "efficiency": {"quality_floor": 0.80, "latency_ms": 80, "target_fps": 30},
            "balanced": {"quality_floor": 0.90, "latency_ms": 50, "target_fps": 60},
            "high": {"quality_floor": 0.95, "latency_ms": 35, "target_fps": 60},
            "extreme": {"quality_floor": 0.98, "latency_ms": 25, "target_fps": 60},
        }
        p = presets.get(name, presets["balanced"])
        return PerformanceProfile(name, p)
