from dataclasses import dataclass, field
from typing import Optional

@dataclass
class Telemetry:
    cpu_util: float = 0.0
    gpu_util: float = 0.0
    npu_util: float = 0.0
    memory_util: float = 0.0
    storage_ms: float = 0.0
    frame_ms: float = 0.0
    fps: float = 0.0
    network_rtt_ms: float = 0.0
    jitter_ms: float = 0.0
    packet_loss: float = 0.0
    encode_ms: float = 0.0
    decode_ms: float = 0.0
    present_ms: float = 0.0
    temperature_c: Optional[float] = None
    power_w: Optional[float] = None

@dataclass
class QualityBudget:
    floor: float = 0.90
    latency_limit_ms: float = 50.0
    thermal_limit_c: float = 45.0

@dataclass
class Recommendation:
    action: str
    reason: str
    expected_cost_change: float = 0.0
    risk: float = 0.0

@dataclass
class PerformanceProfile:
    name: str
    targets: dict = field(default_factory=dict)
