from dataclasses import dataclass

@dataclass
class CloudState:
    rtt_ms: float
    jitter_ms: float
    loss: float
    encode_ms: float
    decode_ms: float
    buffer_ms: float
    fps: float
    bitrate_mbps: float

class CloudController:
    def recommend(self, s: CloudState):
        actions=[]
        if s.jitter_ms > 12 or s.loss > 0.03:
            actions.append("increase_recovery_or_reduce_bitrate")
        if s.buffer_ms > max(80, s.rtt_ms*3):
            actions.append("reduce_queue_depth")
        if s.buffer_ms < max(20, s.rtt_ms):
            actions.append("increase_queue_depth_cautiously")
        if s.encode_ms > 8:
            actions.append("choose_lower_latency_encoder_path")
        if s.decode_ms > 8:
            actions.append("choose_lower_latency_decoder_path")
        if not actions:
            actions.append("hold_current_stream_profile")
        return actions
