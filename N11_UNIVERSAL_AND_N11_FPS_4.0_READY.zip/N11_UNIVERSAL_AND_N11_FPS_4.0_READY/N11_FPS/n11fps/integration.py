class FPSProvider:
    """Small stable bridge for N11 Universal.

    Replace the telemetry source with a real platform adapter when available.
    """
    def __init__(self, engine, telemetry_supplier):
        self.engine=engine
        self.telemetry_supplier=telemetry_supplier

    def __call__(self):
        t=self.telemetry_supplier()
        self.engine.observe(t)
        return t.fps
