from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class PerformanceBudget:
    frame_ms: float = 16.67
    cpu_pct: float = 90.0
    gpu_pct: float = 92.0
    memory_pct: float = 90.0
    thermal_c: float = 44.0
    network_rtt_ms: float = 80.0

    def as_dict(self):
        return self.__dict__.copy()
