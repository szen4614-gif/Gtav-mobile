from ..device_profiles import MOTO_G15
from ..models import Telemetry

class MotoG15Adapter:
    """Application-level profile; values are inputs, not privileged kernel telemetry."""
    name = "moto-g15"

    def profile(self):
        return MOTO_G15.copy()

    def empty_telemetry(self):
        return Telemetry(fps=60.0, frame_ms=1000.0/60.0)
