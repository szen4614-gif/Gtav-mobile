from ..models import Telemetry

class GenericAdapter:
    def snapshot(self):
        return Telemetry()
