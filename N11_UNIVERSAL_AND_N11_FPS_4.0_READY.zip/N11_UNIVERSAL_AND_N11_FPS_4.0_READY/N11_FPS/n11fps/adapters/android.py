class AndroidAdapter:
    """Capability boundary.

    This module does not claim privileged access to Android internals.
    A real Android integration should supply telemetry through JNI/NDK or
    platform APIs and convert it into n11fps.models.Telemetry.
    """
    name = "android"
    def capabilities(self):
        return {
            "adpf": "optional",
            "vulkan": "optional",
            "mediacodec": "optional",
            "frame_pacing": "optional",
            "baseline_profiles": "application-owned",
        }
