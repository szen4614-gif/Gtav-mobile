from .models import QualityBudget

class QualityShield:
    def __init__(self, budget=None):
        self.budget=budget or QualityBudget()

    def allow(self, proposed_quality: float):
        return proposed_quality >= self.budget.floor

    def quality_dividend(self, freed_ms: float, frame_budget_ms=16.67):
        # Conservative reinvestment suggestion, not an automatic visual downgrade.
        return max(0.0, min(1.0, freed_ms / frame_budget_ms))
