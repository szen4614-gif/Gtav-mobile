from n11fps.core import PerformanceEngine
from n11fps.models import Telemetry

def test_gpu_bottleneck():
    e=PerformanceEngine()
    r=e.observe(Telemetry(gpu_util=99,cpu_util=20,frame_ms=24,fps=41))
    assert r["bottleneck"]=="gpu"

def test_network_bottleneck():
    e=PerformanceEngine()
    r=e.observe(Telemetry(gpu_util=20,cpu_util=20,network_rtt_ms=90,jitter_ms=20,packet_loss=0.05))
    assert r["bottleneck"]=="network"

def test_quality_floor():
    e=PerformanceEngine()
    assert e.shield.allow(0.95)
    assert not e.shield.allow(0.80)
