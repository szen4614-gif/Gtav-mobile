from n11fps.adaptive import AdaptiveController
from n11fps.core import PerformanceEngine
from n11fps.device_profiles import MOTO_G15
from n11fps.frame_pacing import FramePacer
from n11fps.models import Telemetry

def test_profile_has_moto_g15_details():
    assert MOTO_G15["gpu"] == "Arm Mali-G52 MC2"
    assert MOTO_G15["abi"] == "arm64-v8a"

def test_adaptive_thermal_response():
    engine = PerformanceEngine()
    result = engine.observe(Telemetry(fps=45, frame_ms=22, gpu_util=50, cpu_util=50, temperature_c=45))
    assert result["adaptive"].action == "reduce_work"

def test_frame_pacing():
    p = FramePacer(60)
    assert p.classify(16.67) == "on_budget"
