# N11 FPS --- Universal Performance Intelligence

N11 FPS is a standalone performance runtime that can also be attached to
N11 Universal.

It is not a graphics-only booster.

It models:

-   CPU/GPU/NPU;
-   memory and storage;
-   thermal state;
-   display/presentation;
-   application workload;
-   rendering;
-   network;
-   cloud streaming;
-   quality and latency budgets.

## Core rule

**Do less work before doing the same work faster.**

Preferred order:

1.  eliminate;
2.  reuse;
3.  predict;
4.  parallelize;
5.  specialize;
6.  compress;
7.  move;
8.  reconstruct;
9.  adapt;
10. reduce quality only within the configured Quality Floor.

## This release

This package contains real executable Python modules for telemetry
modeling, bottleneck diagnosis, work graphs, quality budgets, profiles
and a cloud-streaming model.

Hardware-specific acceleration is represented by adapters. The package
never pretends to have privileged Android/GPU access when it does not.

## Independent

``` text
python -m n11fps.cli inspect
```

## With N11 Universal

Use the FPS provider in `n11fps.integration` and pass it to
`n11lang.runtime.Runtime`.
