# External components and licensing

This repository is an integration project. It does not include or relicense
Minecraft game assets, Microsoft account credentials, proprietary Android GPU
components, or third-party mod distributions. Their versions, permissions and
licenses must be checked at acquisition time.

The `requested_feature_matrix.json` is deliberately conservative: a boundary
is marked `SCAFFOLD` until real executable code is present, and third-party or
platform-owned resources are marked `EXTERNAL`/`NOT_BUNDLED`.
