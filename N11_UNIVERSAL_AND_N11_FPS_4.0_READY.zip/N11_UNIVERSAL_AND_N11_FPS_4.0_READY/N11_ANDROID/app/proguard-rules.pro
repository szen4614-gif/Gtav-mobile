# Native/JNI bridge entry points
-keep class com.n11.minecraft.bridge.** { *; }
# JSON/reflection-free model classes used directly from Android UI/runtime code
-keep class com.n11.minecraft.runtime.** { *; }
