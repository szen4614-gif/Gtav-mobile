package com.n11.minecraft.bridge

import android.content.Context
import com.n11.minecraft.runtime.DeviceProbe
import com.n11.minecraft.runtime.LifecycleState

class N11AndroidBridge {
    companion object { init { System.loadLibrary("n11runtime") } }

    private var state = LifecycleState.CREATED
    private var context: Context? = null

    external fun nativePageSize(): Long
    external fun nativeAbi(): String

    fun initialize(c: Context) { context = c.applicationContext }
    fun onLifecycle(s: LifecycleState) { state = s }

    fun status(): String {
        val c = context ?: return "N11 not initialized"
        val p = DeviceProbe.snapshot(c)
        return buildString {
            append("N11 4.0 READY\n")
            append("ABI=${nativeAbi()}\n")
            append("Page=${nativePageSize()}\n")
            append("Android=${p[\"sdk\"]} (${p[\"android\"]})\n")
            append("Device=${p[\"manufacturer\"]} ${p[\"model\"]}\n")
            append("Memory=${p[\"ramBytes\"]} B\n")
            append("Storage=${p[\"storageBytes\"]} B\n")
            append("State=$state")
        }
    }

    fun supports16kPages() = nativePageSize() == 16384L
}
