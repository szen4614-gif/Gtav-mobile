package com.n11.minecraft.runtime

enum class LifecycleState { CREATED, STARTED, RESUMED, PAUSED, STOPPED, DESTROYED }
