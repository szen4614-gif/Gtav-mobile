package com.n11.minecraft.runtime

import java.io.File

class N11ProcessExecutor {
    fun start(java: File, args: List<String>, workingDirectory: File, environment: Map<String,String> = emptyMap()): Process {
        require(java.exists()) { "Java runtime not found: $java" }
        val pb=ProcessBuilder(listOf(java.absolutePath)+args).directory(workingDirectory)
        pb.environment().putAll(environment)
        pb.redirectErrorStream(true)
        return pb.start()
    }
}
