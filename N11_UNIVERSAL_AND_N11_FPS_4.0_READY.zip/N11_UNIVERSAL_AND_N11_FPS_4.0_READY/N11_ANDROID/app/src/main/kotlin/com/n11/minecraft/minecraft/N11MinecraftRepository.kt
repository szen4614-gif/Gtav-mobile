package com.n11.minecraft.minecraft

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class N11MinecraftRepository(private val context: Context) {
    companion object {
        private const val MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
    }

    data class VersionInfo(val id: String, val type: String, val url: String, val sha1: String)

    private val root = File(context.getExternalFilesDir(null), "minecraft").apply { mkdirs() }
    private val metaDir = File(root, "meta").apply { mkdirs() }

    fun latestRelease(): VersionInfo {
        val manifest = JSONObject(getText(MANIFEST_URL))
        val id = manifest.getJSONObject("latest").getString("release")
        return findVersion(manifest, id) ?: error("Latest release $id not present in manifest")
    }

    fun listReleases(limit: Int = 24): List<VersionInfo> {
        val manifest = JSONObject(getText(MANIFEST_URL))
        val out = ArrayList<VersionInfo>()
        val versions = manifest.getJSONArray("versions")
        for (i in 0 until minOf(limit, versions.length())) {
            val o = versions.getJSONObject(i)
            if (o.optString("type") == "release") {
                out += VersionInfo(o.getString("id"), o.getString("type"), o.getString("url"), o.getString("sha1"))
            }
        }
        return out
    }

    fun downloadVersionJson(version: VersionInfo): File {
        val destination = File(metaDir, "${version.id}.json")
        val text = getText(version.url)
        destination.writeText(text)
        return destination
    }

    fun gameDirectory(): File = root

    private fun findVersion(manifest: JSONObject, id: String): VersionInfo? {
        val versions = manifest.getJSONArray("versions")
        for (i in 0 until versions.length()) {
            val o = versions.getJSONObject(i)
            if (o.getString("id") == id) {
                return VersionInfo(o.getString("id"), o.getString("type"), o.getString("url"), o.getString("sha1"))
            }
        }
        return null
    }

    private fun getText(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "N11-Minecraft/4.0-ready")
            setRequestProperty("Accept", "application/json")
        }
        return try {
            require(c.responseCode in 200..299) { "HTTP ${c.responseCode} for $url" }
            c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
