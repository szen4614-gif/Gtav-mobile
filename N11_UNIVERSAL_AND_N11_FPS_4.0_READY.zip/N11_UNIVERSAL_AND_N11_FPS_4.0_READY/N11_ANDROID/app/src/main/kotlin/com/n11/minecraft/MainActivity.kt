package com.n11.minecraft

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.n11.minecraft.bridge.N11AndroidBridge
import com.n11.minecraft.minecraft.N11MinecraftRepository
import com.n11.minecraft.runtime.LifecycleState
import com.n11.minecraft.runtime.N11RuntimeInstaller
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val bridge = N11AndroidBridge()
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bridge.initialize(this)
        bridge.onLifecycle(LifecycleState.CREATED)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 48, 32, 32)
        }
        val title = TextView(this).apply {
            text = "N11 Minecraft Java Mobile\n4.0 READY"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 15f
            setPadding(0, 24, 0, 24)
            text = bridge.status()
        }
        val javaButton = Button(this).apply {
            text = "Instalar Java 21"
            setOnClickListener { installRuntime(21, this) }
        }
        val versionsButton = Button(this).apply {
            text = "Verificar Minecraft"
            setOnClickListener { checkMinecraft(this) }
        }
        root.addView(title, ViewGroup.LayoutParams(-1, -2))
        root.addView(status, ViewGroup.LayoutParams(-1, -2))
        root.addView(javaButton, ViewGroup.LayoutParams(-1, -2))
        root.addView(versionsButton, ViewGroup.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun installRuntime(major: Int, button: Button) {
        button.isEnabled = false
        status.text = "Preparando Java $major...\n${bridge.status()}"
        executor.execute {
            val result = runCatching { N11RuntimeInstaller(this).install(N11RuntimeInstaller.forMajor(major)) }
            runOnUiThread {
                result.fold(
                    onSuccess = { java -> status.text = "Java $major pronto:\n${java.absolutePath}\n\n${bridge.status()}" },
                    onFailure = { error -> status.text = "Falha no Java $major: ${error.message}\n\n${bridge.status()}" }
                )
                button.isEnabled = true
            }
        }
    }

    private fun checkMinecraft(button: Button) {
        button.isEnabled = false
        status.text = "Consultando manifest oficial do Minecraft..."
        executor.execute {
            val result = runCatching {
                val repo = N11MinecraftRepository(this)
                val latest = repo.latestRelease()
                repo.downloadVersionJson(latest)
                latest
            }
            runOnUiThread {
                result.fold(
                    onSuccess = { latest -> status.text = "Último release oficial detectado: ${latest.id}\nMetadados salvos no diretório N11." },
                    onFailure = { error -> status.text = "Falha ao consultar Minecraft: ${error.message}" }
                )
                button.isEnabled = true
            }
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        bridge.onLifecycle(LifecycleState.DESTROYED)
        super.onDestroy()
    }

    override fun onStart() { super.onStart(); bridge.onLifecycle(LifecycleState.STARTED) }
    override fun onResume() { super.onResume(); bridge.onLifecycle(LifecycleState.RESUMED) }
    override fun onPause() { bridge.onLifecycle(LifecycleState.PAUSED); super.onPause() }
    override fun onStop() { bridge.onLifecycle(LifecycleState.STOPPED); super.onStop() }
}
