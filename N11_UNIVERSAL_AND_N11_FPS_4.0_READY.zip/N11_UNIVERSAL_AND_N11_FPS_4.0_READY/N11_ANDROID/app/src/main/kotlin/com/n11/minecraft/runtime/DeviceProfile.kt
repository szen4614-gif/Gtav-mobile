package com.n11.minecraft.runtime

data class DeviceProfile(
    val model: String,
    val soc: String,
    val gpu: String,
    val abi: String,
    val displayHz: Int,
    val recommendedTargetFps: Int
)

object MotoG15Profile {
    val value = DeviceProfile(
        model = "Motorola moto g15",
        soc = "MediaTek Helio G81 Extreme",
        gpu = "Arm Mali-G52 MC2",
        abi = "arm64-v8a",
        displayHz = 60,
        recommendedTargetFps = 60
    )
}
