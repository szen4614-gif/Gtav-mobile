package com.n11.minecraft.runtime

import android.app.Service
import android.content.Intent
import android.os.IBinder

class N11RuntimeService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}
