package com.n11.minecraft.runtime

import android.content.Context
import java.io.File

data class LaunchSpec(val java: File,val args: List<String>,val gameDir: File)

class N11LaunchCoordinator(private val context: Context) {
    fun validate(spec: LaunchSpec) {
        require(spec.java.isFile && spec.java.canExecute()) { "Java executable unavailable" }
        require(spec.gameDir.isDirectory) { "Game directory unavailable" }
        require(spec.args.isNotEmpty()) { "Empty launch arguments" }
    }
    fun launch(spec: LaunchSpec): Process { validate(spec); return N11ProcessExecutor().start(spec.java,spec.args,spec.gameDir) }
}
