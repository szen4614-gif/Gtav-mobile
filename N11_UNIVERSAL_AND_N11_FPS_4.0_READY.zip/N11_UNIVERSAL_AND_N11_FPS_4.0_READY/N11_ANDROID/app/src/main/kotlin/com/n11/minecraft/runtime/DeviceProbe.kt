package com.n11.minecraft.runtime

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs

object DeviceProbe {
    fun snapshot(context: Context): Map<String, String> {
        val am=context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info=ActivityManager.MemoryInfo().also(am::getMemoryInfo)
        val fs=StatFs(Environment.getDataDirectory().path)
        return mapOf("model" to Build.MODEL,"manufacturer" to Build.MANUFACTURER,"android" to Build.VERSION.RELEASE,"sdk" to Build.VERSION.SDK_INT.toString(),"abi" to Build.SUPPORTED_ABIS.firstOrNull().orEmpty(),"ramBytes" to info.totalMem.toString(),"storageBytes" to (fs.blockCountLong*fs.blockSizeLong).toString(),"pageSize" to System.getProperty("os.pageSize","unknown"))
    }
}
