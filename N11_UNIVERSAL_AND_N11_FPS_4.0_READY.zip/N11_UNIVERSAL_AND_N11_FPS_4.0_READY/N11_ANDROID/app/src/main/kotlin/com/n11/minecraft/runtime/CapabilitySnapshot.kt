package com.n11.minecraft.runtime

data class CapabilitySnapshot(
    val androidApi: Int,
    val abi: String,
    val nativeBridge: Boolean,
    val sixteenKbAware: Boolean
)
