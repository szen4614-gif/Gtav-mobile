package com.n11.minecraft.runtime

import android.content.Context
import android.os.Build
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.security.MessageDigest
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.tukaani.xz.XZInputStream

class N11RuntimeInstaller(private val context: Context) {
    data class Artifact(val major: Int, val url: String, val sha256: String, val optional: Boolean = false)

    companion object {
        val JRE8 = Artifact(
            8,
            "https://github.com/AngelAuraMC/angelauramc-openjdk-build/releases/download/download_jre8/jre8-android-arm64.tar.xz",
            "64ba5c89d6f4c88da765a6c512b0ba14a7a64976fe95e105fa9b05c833fdd07b",
            optional = true
        )
        val JRE17 = Artifact(
            17,
            "https://github.com/AngelAuraMC/angelauramc-openjdk-build/releases/download/download/jre17-android-arm64.tar.xz",
            "e162c860fe05ee4a4e4af7606437419879f6c748386a7b09fa77d10db6a64091"
        )
        val JRE21 = Artifact(
            21,
            "https://github.com/AngelAuraMC/angelauramc-openjdk-build/releases/download/download/jre21-android-arm64.tar.xz",
            "8d41ec401ee59f7722df60ed991f81ad146e130452804bfdd8a05d3436f7bbfe"
        )
        val JRE25 = Artifact(
            25,
            "https://github.com/AngelAuraMC/angelauramc-openjdk-build/releases/download/download/jre25-android-arm64.tar.xz",
            "d3eb7afe2240c26728a1bb440502c5f18ac3883e932d202dd7f0c9bcbbce4c37"
        )

        fun forMajor(major: Int): Artifact = when (major) {
            8 -> JRE8
            17 -> JRE17
            21 -> JRE21
            25 -> JRE25
            else -> error("Unsupported Java major: $major")
        }
    }

    fun install(a: Artifact): File {
        require(Build.SUPPORTED_ABIS.contains("arm64-v8a")) { "N11 ready build requires ARM64" }
        val root = File(context.filesDir, "runtimes/jre${a.major}")
        val archive = File(context.cacheDir, "jre${a.major}.tar.xz")
        val part = File(context.cacheDir, "jre${a.major}.tar.xz.part")
        if (root.exists()) root.deleteRecursively()
        root.mkdirs()
        download(a.url, archive, part)
        verify(archive, a.sha256)
        extract(archive, root)
        archive.delete()
        findJava(root)?.let { java ->
            java.setExecutable(true, false)
            return java
        }
        error("JRE ${a.major} extracted without bin/java")
    }

    private fun download(url: String, out: File, part: File) {
        var last: Throwable? = null
        repeat(3) { attempt ->
            try {
                if (part.exists()) part.delete()
                val c = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 30_000
                    readTimeout = 120_000
                    instanceFollowRedirects = true
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "N11-Minecraft/4.0-ready")
                    setRequestProperty("Accept", "application/octet-stream")
                }
                try {
                    val code = c.responseCode
                    require(code in 200..299) { "Download failed HTTP $code for $url" }
                    c.inputStream.use { input ->
                        FileOutputStream(part).use { output ->
                            input.copyTo(output, 1024 * 1024)
                            output.fd.sync()
                        }
                    }
                } finally {
                    c.disconnect()
                }
                if (part.length() <= 0L) error("Downloaded archive is empty")
                if (out.exists()) out.delete()
                check(part.renameTo(out)) { "Failed to finalize runtime archive" }
                return
            } catch (t: Throwable) {
                last = t
                if (attempt == 2) throw t
            }
        }
        throw last ?: IllegalStateException("Download failed")
    }

    private fun verify(file: File, expected: String) {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(1024 * 1024)
            var n: Int
            while (input.read(buffer).also { n = it } > 0) md.update(buffer, 0, n)
        }
        val actual = md.digest().joinToString("") { "%02x".format(it) }
        check(actual.equals(expected, ignoreCase = true)) {
            "JRE SHA-256 mismatch: expected $expected, got $actual"
        }
    }

    private fun extract(archive: File, dest: File) {
        val base = dest.canonicalFile
        XZInputStream(archive.inputStream()).use { xz ->
            TarArchiveInputStream(xz).use { tar ->
                var entry: TarArchiveEntry? = tar.nextTarEntry
                while (entry != null) {
                    val e = entry!!
                    val clean = e.name.removePrefix("./")
                    require(clean.isNotBlank()) { "Unsafe archive entry" }
                    require(clean.split('/').none { it == ".." }) { "Unsafe archive path: ${e.name}" }
                    val target = File(base, clean).canonicalFile
                    require(target.path == base.path || target.path.startsWith(base.path + File.separator)) {
                        "Unsafe archive path: ${e.name}"
                    }
                    when {
                        e.isDirectory -> target.mkdirs()
                        e.isSymbolicLink -> {
                            val linkName = e.linkName.removePrefix("./")
                            require(!linkName.startsWith("/")) { "Unsafe symbolic link" }
                            require(linkName.split('/').none { it == ".." }) { "Unsafe symbolic link" }
                            target.parentFile?.mkdirs()
                            val linkTarget = File(target.parentFile, linkName).canonicalFile
                            require(linkTarget.path == base.path || linkTarget.path.startsWith(base.path + File.separator)) { "Unsafe symbolic link target" }
                            runCatching { Files.deleteIfExists(target.toPath()) }
                            Files.createSymbolicLink(target.toPath(), target.parentFile.resolve(linkName).toPath().normalize())
                        }
                        else -> {
                            target.parentFile?.mkdirs()
                            target.outputStream().use { tar.copyTo(it) }
                            val executable = (e.mode and 0b001001001) != 0
                            if (executable) target.setExecutable(true, false)
                        }
                    }
                    entry = tar.nextTarEntry
                }
            }
        }
    }

    private fun findJava(root: File): File? = root.walkTopDown().firstOrNull {
        it.isFile && it.name == "java" && it.parentFile?.name == "bin"
    }
}
