package com.n11.minecraft.renderer

data class RendererDescriptor(val id:String,val name:String,val minSdk:Int,val requiresVulkan:Boolean,val nativeLibraries:List<String>)

object N11RendererRegistry {
    val builtIns=listOf(
        RendererDescriptor("gles","OpenGL ES",26,false,listOf()),
        RendererDescriptor("gl4es","GL4ES",26,false,listOf("libgl4es.so")),
        RendererDescriptor("vulkan","Vulkan",26,true,listOf()),
        RendererDescriptor("angle","ANGLE",26,false,listOf("libEGL_angle.so","libGLESv2_angle.so")),
        RendererDescriptor("software","Software fallback",26,false,listOf())
    )
    fun select(vulkan:Boolean,gles:Boolean,gl4es:Boolean,angle:Boolean):RendererDescriptor = when {
        vulkan -> builtIns.first{it.id=="vulkan"}; gles && gl4es -> builtIns.first{it.id=="gl4es"}; gles && angle -> builtIns.first{it.id=="angle"}; gles -> builtIns.first{it.id=="gles"}; else -> builtIns.first{it.id=="software"}
    }
}
