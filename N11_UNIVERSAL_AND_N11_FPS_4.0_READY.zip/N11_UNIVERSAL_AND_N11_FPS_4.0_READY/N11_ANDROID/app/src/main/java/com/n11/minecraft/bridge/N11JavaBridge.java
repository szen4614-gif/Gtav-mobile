package com.n11.minecraft.bridge;

/** Small Java-facing bridge for Java runtimes and launcher backends. */
public final class N11JavaBridge {
    private N11JavaBridge() {}

    public static String normalizeAbi(String abi) {
        if (abi == null) return "unknown";
        return abi.trim().toLowerCase().replace("arm64-v8a", "arm64-v8a");
    }

    public static boolean supportsArm64(String abi) {
        return "arm64-v8a".equals(normalizeAbi(abi));
    }
}
