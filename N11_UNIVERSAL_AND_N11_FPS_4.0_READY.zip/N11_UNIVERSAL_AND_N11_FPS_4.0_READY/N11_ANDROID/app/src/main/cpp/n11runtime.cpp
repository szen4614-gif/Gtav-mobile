#include <jni.h>
#include <android/log.h>
#include <unistd.h>

#define LOG_TAG "N11Runtime"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" JNIEXPORT jlong JNICALL
Java_com_n11_minecraft_bridge_N11AndroidBridge_nativePageSize(JNIEnv*, jobject) {
    long p = sysconf(_SC_PAGESIZE);
    LOGI("Detected system page size: %ld", p);
    return static_cast<jlong>(p);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_n11_minecraft_bridge_N11AndroidBridge_nativeAbi(JNIEnv* env, jobject) {
#if defined(__aarch64__)
    return env->NewStringUTF("arm64-v8a");
#elif defined(__arm__)
    return env->NewStringUTF("armeabi-v7a");
#else
    return env->NewStringUTF("unknown");
#endif
}
