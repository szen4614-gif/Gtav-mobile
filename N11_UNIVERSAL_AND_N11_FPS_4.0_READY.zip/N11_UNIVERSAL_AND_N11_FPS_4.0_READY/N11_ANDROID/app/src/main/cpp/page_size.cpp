#include <unistd.h>
extern "C" long n11_page_size() { return sysconf(_SC_PAGESIZE); }
