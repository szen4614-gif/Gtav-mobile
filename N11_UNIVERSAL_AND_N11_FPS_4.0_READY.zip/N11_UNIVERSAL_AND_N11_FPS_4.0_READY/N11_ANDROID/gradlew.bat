@echo off
where gradle >nul 2>&1
if %ERRORLEVEL%==0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo N11 Android project: install Gradle 9.6+ before building.
exit /b 127

