# N11 Android

Android is a platform adapter around N11, not a second independent optimizer.
Kotlin/Java code handles Android lifecycle/UI concerns; JNI enters the native
N11 boundary; N11 FPS consumes measurements and returns conservative
performance decisions.

The module is intentionally ARM64-only because the target device class is
ARM64 and the native runtime boundary is designed for `arm64-v8a`.
