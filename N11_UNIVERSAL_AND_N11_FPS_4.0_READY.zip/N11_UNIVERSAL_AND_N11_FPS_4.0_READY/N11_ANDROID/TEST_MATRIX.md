# Android validation matrix

These are the required validation tracks for the Android binary build. The
source package includes the contracts and preflight checks; tests that require
a real Android device/emulator remain external.

| Test | Source/preflight | Device required |
|---|---|---|
| JNI smoke | `n11runtime.cpp` exports | Yes |
| 16 KB page | runtime `sysconf(_SC_PAGESIZE)` + NDK configuration | Yes/16 KB emulator |
| ARM64 ELF alignment | APK/AAB post-build analysis | Build artifact |
| Lifecycle | `MainActivity` + service bridge | Yes |
| Native crash recovery | process/watchdog contract | Yes |
| Thermal/sustained performance | N11 FPS telemetry | Yes |
| Minecraft launch | backend contracts + external assets/runtime | Yes |

