# N11 Android Build

This package is prepared for GitHub Actions. The workflow installs the exact toolchain and produces an installable debug APK as a downloadable artifact.

## Toolchain

- Android API 36
- Android Gradle Plugin 9.2.0
- Gradle 9.4.1
- Kotlin Gradle Plugin 2.2.10
- JDK 17
- Android NDK 28.2.13676358
- CMake 3.22.1
- ARM64 (`arm64-v8a`)

## GitHub

Push the repository and open **Actions → N11 Android Build → Run workflow**. The workflow validates the source, builds the APK, verifies its signature and checks 16 KB ZIP alignment, then publishes `app-debug.apk` as an artifact.

## Local

A standard Gradle wrapper JAR is intentionally not vendored in this source-only archive. Use Gradle 9.4.1 locally, or use the included GitHub Actions workflow.

## Runtime

JRE 8, 17, 21 and 25 ARM64 archives are referenced by pinned SHA-256 values. JRE 8 is marked optional for legacy Minecraft versions; JRE 21 is the interactive default in the bootstrap UI.

The APK does not ship Minecraft itself, Mojang account tokens, or third-party renderer binaries. Those components are acquired/managed at runtime under their applicable licenses.

Android's current 16 KB page-size guidance recommends AGP 8.5.1+ and NDK r28+; N11 also keeps explicit 16 KB linker flags on its native target.
