# N11 Universal + N11 FPS 4.0 — READY

This release is the GitHub-buildable N11 Android package. It contains an ARM64 Android application shell, native bridge, runtime installer, Mojang metadata access, encrypted token storage, renderer registry, and N11 FPS modules.

The Android UI now performs real device probing, can install the pinned JRE 21 runtime, and can query/download official Mojang version metadata without requiring a Python runtime.

The GitHub Actions workflow is the supported APK build path and emits an installable debug APK artifact after source, lint, signature and 16 KB alignment checks.

The launcher is **not represented as a finished Zalith-equivalent Minecraft runtime** yet: the actual LWJGL/GL4ES/OpenAL native stack, Minecraft library/native/assets resolver on Android, Microsoft interactive sign-in UI, loader adapters (Fabric/Forge/NeoForge/Quilt), and full in-game process/render integration still require real upstream binaries/source integration and device validation. This package is therefore build-ready and functional as an Android runtime/bootstrap layer, not a claim of feature parity with Zalith Launcher 2.
