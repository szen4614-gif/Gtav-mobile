# N11 3.0 release notes

## Corrected from 2.0

- Removed generated `__pycache__` files from the distribution.
- Added root-level validation and capability/status metadata.
- Added Android/Java/Kotlin/JNI/NDK project structure instead of only a
  Python capability boundary.
- Added a concrete Moto G15 hardware profile and runtime constraints.
- Added explicit download, integrity, cache and resume contracts.
- Added Minecraft version/assets/library/runtime launch abstractions.
- Added mod-loader and rendering backend adapters.
- Added foreground/background, low-memory, thermal and crash-recovery state
  models at the Android boundary.
- Added N11 FPS adaptive/performance modules and tests.

## Important technical constraint

An interface is not a native implementation. The release therefore marks
vendor/private APIs, Minecraft/Microsoft services, and third-party runtime
artifacts as external/scaffold instead of pretending they are already
embedded.
