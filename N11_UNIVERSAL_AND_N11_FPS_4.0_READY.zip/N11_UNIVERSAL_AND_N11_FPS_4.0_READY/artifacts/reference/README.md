# Reference APK

The original uploaded APK is retained here for comparison. Its manifest and
DEX are only a small launcher shell/diagnostic surface; it is not a bundled
Minecraft/JRE/LWJGL runtime. The source under `N11_ANDROID/` is the new build
source rather than an attempt to hide those missing binary dependencies.
