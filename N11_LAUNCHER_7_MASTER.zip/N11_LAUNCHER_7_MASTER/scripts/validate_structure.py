from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]
req=["N11_ANDROID/app/build.gradle.kts","N11_ANDROID/app/src/main/AndroidManifest.xml","N11_ANDROID/app/src/main/cpp/CMakeLists.txt","N11_CORE/src/main/kotlin/com/n11/core/Models.kt","N11_RUNTIME/src/main/kotlin/com/n11/runtime/Runtime.kt","N11_MINECRAFT/src/main/kotlin/com/n11/minecraft/Models.kt","N11_PERFORMANCE/src/main/kotlin/com/n11/performance/Engines.kt"]
missing=[x for x in req if not (r/x).is_file()]
assert not missing, missing
json.load(open(r/"config/n11/instance.example.json",encoding="utf-8"))
print("N11 structure: OK")
