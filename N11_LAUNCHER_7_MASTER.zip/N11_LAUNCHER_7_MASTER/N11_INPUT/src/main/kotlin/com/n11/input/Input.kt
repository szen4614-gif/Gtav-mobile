package com.n11.input
data class TouchBinding(val action:String,val x:Float,val y:Float,val radius:Float)
data class ControllerProfile(val id:String,val name:String,val bindings:Map<String,Int>)
