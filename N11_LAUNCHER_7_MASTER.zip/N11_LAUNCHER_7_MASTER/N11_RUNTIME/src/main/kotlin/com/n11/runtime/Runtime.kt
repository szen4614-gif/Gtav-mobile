package com.n11.runtime
data class RuntimeSpec(val id:String,val javaMajor:Int,val abi:String,val url:String,val sha256:String,val archiveType:String="tar.xz")
class RuntimeSelector{fun select(javaMajor:Int,available:List<RuntimeSpec>)=available.firstOrNull{it.javaMajor==javaMajor&&it.abi=="arm64-v8a"}}
