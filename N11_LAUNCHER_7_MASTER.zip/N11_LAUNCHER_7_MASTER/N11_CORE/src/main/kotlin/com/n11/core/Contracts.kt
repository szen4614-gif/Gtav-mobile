package com.n11.core
interface N11Engine { suspend fun evaluate(instance:N11Instance):List<DiagnosticItem> }
interface RepairAction { suspend fun execute():Result<Unit> }
