package com.n11.core
data class N11Instance(val id:String,val name:String,val minecraftVersion:String,val javaMajor:Int,val loader:String?=null,val memoryMb:Int=2048)
data class LaunchSession(val id:String,val instanceId:String,val createdAtMs:Long,val stages:MutableList<LaunchStage> = mutableListOf())
enum class LaunchStage{AUTH,RUNTIME,VERSION,LIBRARIES,ASSETS,NATIVES,JVM,RENDERER,READY,FAILED}
data class DiagnosticItem(val id:String,val severity:Severity,val title:String,val detail:String,val repairable:Boolean)
enum class Severity{OK,INFO,WARNING,ERROR}
