package com.n11.nativebridge
data class NativeHealth(val abi:String,val pageSize:Int,val expectedPageSize:Int=16384){val compatible16k:Boolean get()=pageSize==expectedPageSize||pageSize==4096}
