package com.n11.instance
import com.n11.core.N11Instance
import java.io.File
class InstanceRepository(private val root:File){fun directory(id:String)=File(root,"instances/$id");fun create(i:N11Instance)=directory(i.id).also{it.mkdirs()};fun delete(id:String)=directory(id).deleteRecursively()}
