package com.n11.launcher
import android.app.Activity
import android.os.Bundle
import android.widget.TextView
class MainActivity: Activity(){ override fun onCreate(b:Bundle?){super.onCreate(b); setContentView(TextView(this).apply{text="N11 Launcher 7\nCore modular • ARM64 • diagnostics • performance"; textSize=24f})} }
