package com.n11.launcher
class N11AndroidBridge { companion object { init { System.loadLibrary("n11runtime") } } external fun nativePageSize():Int; external fun nativeAbi():String }
