#include <jni.h>
#include <unistd.h>
extern "C" JNIEXPORT jint JNICALL Java_com_n11_launcher_N11AndroidBridge_nativePageSize(JNIEnv*,jobject){return (jint)getpagesize();}
extern "C" JNIEXPORT jstring JNICALL Java_com_n11_launcher_N11AndroidBridge_nativeAbi(JNIEnv* e,jobject){return e->NewStringUTF("arm64-v8a");}
