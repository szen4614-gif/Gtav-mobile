plugins { id("com.android.application") }

android {
 namespace="com.n11.launcher"
 compileSdk=36
 defaultConfig { applicationId="com.n11.launcher"; minSdk=26; targetSdk=36; versionCode=700; versionName="7.0.0"; ndk { abiFilters += "arm64-v8a" } }
 externalNativeBuild { cmake { path=file("src/main/cpp/CMakeLists.txt"); version="3.22.1" } }
 compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17 }
 packaging { jniLibs.useLegacyPackaging=false }
}
dependencies { implementation("androidx.core:core-ktx:1.17.0"); implementation("androidx.activity:activity-ktx:1.11.0") }
