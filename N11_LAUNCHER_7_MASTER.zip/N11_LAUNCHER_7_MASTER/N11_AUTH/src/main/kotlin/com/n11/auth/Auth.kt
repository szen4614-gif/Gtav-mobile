package com.n11.auth
data class AccountProfile(val accountId:String,val gamertag:String?,val minecraftUuid:String?,val minecraftAccessToken:String?)
interface AuthProvider{suspend fun login():Result<AccountProfile>;suspend fun refresh(accountId:String):Result<AccountProfile>;suspend fun logout(accountId:String)}
