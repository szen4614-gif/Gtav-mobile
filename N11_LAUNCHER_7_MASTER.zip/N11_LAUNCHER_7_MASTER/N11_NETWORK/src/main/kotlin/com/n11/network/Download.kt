package com.n11.network
data class DownloadSpec(val id:String,val url:String,val destination:java.io.File,val expectedSha256:String?=null,val expectedSize:Long?=null)
interface DownloadEngine{suspend fun download(spec:DownloadSpec):Result<java.io.File>}
