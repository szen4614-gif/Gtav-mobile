package com.n11.diagnostics
import com.n11.core.*
import java.io.File
class LaunchDoctor{fun checkJava(j:File)=if(j.isFile&&j.canExecute())DiagnosticItem("java",Severity.OK,"Java disponível",j.absolutePath,false)else DiagnosticItem("java",Severity.ERROR,"Java ausente","Runtime não encontrado ou não executável.",true);fun checkStorage(d:File,required:Long)=if(d.usableSpace>=required)DiagnosticItem("storage",Severity.OK,"Armazenamento suficiente","${d.usableSpace} bytes disponíveis.",false)else DiagnosticItem("storage",Severity.ERROR,"Armazenamento insuficiente","Necessários $required bytes.",false)}
