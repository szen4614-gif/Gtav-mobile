# N11 Launcher 7 Master

Base modular para transformar o N11 em launcher real de Minecraft Java no Android.

Inclui contratos para runtime Java, Minecraft manifest/version resolver, instancias, downloads, storage CAS, autenticação, performance, thermal/memory guards, diagnostics, renderer/input/audio, mods, plugins, JNI/16KB e CI.

Esta base não redistribui Minecraft/client.jar/assets nem finge que renderer/JVM nativos já estão integrados: essas partes exigem componentes apropriados, licenças e validação em dispositivo real.
