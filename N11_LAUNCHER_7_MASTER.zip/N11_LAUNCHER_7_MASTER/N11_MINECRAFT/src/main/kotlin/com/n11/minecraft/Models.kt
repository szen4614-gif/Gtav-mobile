package com.n11.minecraft
data class MinecraftVersion(val id:String,val type:String,val url:String,val sha1:String?=null)
data class LibraryArtifact(val coordinate:String,val url:String,val sha1:String?,val size:Long?)
data class LaunchPlan(val javaExecutable:String,val jvmArgs:List<String>,val classpath:List<String>,val mainClass:String,val gameArgs:List<String>){fun command()=listOf(javaExecutable)+jvmArgs+listOf("-cp",classpath.joinToString(java.io.File.pathSeparator),mainClass)+gameArgs}
interface VersionManifestClient{suspend fun getManifest():String;suspend fun getVersionJson(url:String):String}
