package com.n11.performance
data class PerformanceSnapshot(val fps:Double,val onePercentLow:Double,val frameTimeMs:Double,val ramUsedMb:Long,val thermalStatus:Int,val cpuLoad:Double)
data class PerformanceProfile(val name:String,val targetFps:Int,val maxRamMb:Int,val renderDistance:Int,val simulationDistance:Int,val resolutionScale:Float,val vsync:Boolean,val particles:String)
class N11AdaptiveEngine{fun recommend(s:PerformanceSnapshot,p:PerformanceProfile):PerformanceProfile{val bad=s.frameTimeMs>(1000.0/p.targetFps)*1.2||s.thermalStatus>=4;if(!bad)return p;return p.copy(renderDistance=(p.renderDistance-2).coerceAtLeast(4),simulationDistance=(p.simulationDistance-1).coerceAtLeast(3),resolutionScale=(p.resolutionScale-.10f).coerceAtLeast(.60f))}}
class N11MemoryGuard{fun recommendedHeapMb(total:Long,available:Long,lowEnd:Boolean):Int{val reserve=if(lowEnd)1200 else 1600;return (minOf(available-reserve,total*45/100)).coerceIn(768,6144).toInt()}}
