package com.n11.plugin
data class PluginManifest(val id:String,val name:String,val version:String,val apiVersion:Int,val capabilities:Set<String>,val entrypoint:String)
object PluginCapabilities{const val DIAGNOSTICS="diagnostics";const val INSTANCE_READ="instance.read";const val INSTANCE_WRITE="instance.write";const val RENDERER="renderer"}
