package com.n11.mods
data class ModMetadata(val id:String,val version:String,val minecraftVersions:Set<String>,val loaders:Set<String>,val dependencies:Set<String>=emptySet(),val conflicts:Set<String>=emptySet(),val sha256:String?=null)
data class ModConflict(val modA:String,val modB:String,val reason:String)
class ModConflictGraph{fun conflicts(mods:List<ModMetadata>)=mods.flatMap{a->mods.filter{it.id!=a.id&&(it.id in a.conflicts||a.id in it.conflicts)}.map{b->ModConflict(a.id,b.id,"Conflito declarado pela metadata.")}}.distinctBy{setOf(it.modA,it.modB)}}
