# Roadmap
P0 Foundation/CI/security/16KB.
P1 Runtime + official Minecraft manifest + real process launch.
P2 Native JVM + renderer + input + audio.
P3 N11 intelligence systems.
P4 mod loaders/modpacks/snapshots/migration.
P5 plugins, compatibility database e hardening.
