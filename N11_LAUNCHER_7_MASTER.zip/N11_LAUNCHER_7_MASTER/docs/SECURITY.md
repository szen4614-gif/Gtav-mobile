# Security
Tokens no Android Keystore; HTTPS; hashes; proteção contra path traversal; plugins por capabilities; logs sem secrets; dependências e NOTICE documentados; Minecraft/client/assets não são redistribuídos pelo código-fonte.
