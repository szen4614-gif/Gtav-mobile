# Sistemas exclusivos N11

Adaptive Engine, FPS Intelligence, Thermal Guard, Memory Guard, Render Auto, Compatibility Matrix, Crash Intelligence, Safe Launch, Instance Snapshot, Download Intelligence, Storage Optimizer, Mod Safety/Conflict Graph, Launch Doctor, Performance Lab, Profile Forge, Dynamic Resolution, Battery Mode, Network Resilience, Offline Vault, Repair Engine, Migration Engine, Device Profile, Input Lab, Accessibility Layer, Plugin Trust, Local Telemetry, Explain Mode, One-Tap Repair, Low-End Mode, Modpack Profiler, Recovery Journal, Experiment Profiles, Native Health, Renderer Quirk DB, Thermal Benchmark, Smart Cache e Launch Timeline.

Regra central: toda automação deve ser explicável, reversível quando possível e baseada em métricas observáveis.
