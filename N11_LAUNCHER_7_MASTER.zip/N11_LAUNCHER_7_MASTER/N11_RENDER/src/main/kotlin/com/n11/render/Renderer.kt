package com.n11.render
enum class RendererKind{GL4ES,VULKAN,ANGLE,SOFTWARE}
data class RendererCapabilities(val kind:RendererKind,val supported:Boolean,val maxTextureSize:Int=0,val extensions:Set<String> = emptySet())
interface N11Renderer{fun capabilities():RendererCapabilities;fun initialize():Result<Unit>;fun shutdown()}
class RendererSelector{fun choose(c:List<RendererCapabilities>)=c.firstOrNull{it.supported}}
