package com.n11.audio
interface AudioBackend{fun initialize():Result<Unit>;fun setMasterVolume(volume:Float);fun shutdown()}
