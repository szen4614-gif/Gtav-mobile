package com.n11.storage
import java.io.File
import java.security.MessageDigest
class ContentStore(private val root:File){fun pathForSha256(h:String)=File(root,"sha256/${h.take(2)}/$h");fun verify(f:File,h:String):Boolean{val md=MessageDigest.getInstance("SHA-256");f.inputStream().use{input->val b=ByteArray(65536);while(true){val n=input.read(b);if(n<0)break;md.update(b,0,n)}};return md.digest().joinToString(""){ "%02x".format(it)}.equals(h,true)}}
