plugins {
    id("com.android.application") version "9.2.0" apply false
}
